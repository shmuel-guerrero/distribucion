<?php require_once show_template('header-configured'); ?>
<div class="panel-heading">
	<h3 class="panel-title" data-header="true">
		<span class="glyphicon glyphicon-option-vertical"></span>
		<strong>Gastos de efectivo</strong>
	</h3>
</div>
<div class="panel-body">
	<div class="alert alert-info">
		<strong>No se encontraron resultados.</strong>
		<p>Vuelva a reintentar más tarde.</p>
	</div>
</div>
<?php require_once show_template('footer-configured'); ?>