<?php 
	header('Location: ../');
	exit;
?>