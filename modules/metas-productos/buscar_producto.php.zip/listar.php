<?php
require config . '/poligono.php';
// Obtiene la moneda oficial
$moneda = $db->from('inv_monedas')->where('oficial', 'S')->fetch_first();
$moneda = ($moneda) ? '(' . $moneda['sigla'] . ')' : '';

$Consulta = $db->query("SELECT m.id_meta,m.monto,m.fecha_inicio,m.fecha_fin,m.distribuidor_id,e.nombres,e.paterno,e.materno, e.id_empleado
                        FROM inv_metas_distribuidor AS m
                        LEFT JOIN sys_empleados AS e ON e.id_empleado=m.distribuidor_id
                        ORDER BY m.id_meta DESC")->fetch();
// echo json_encode($Consulta);
$hoy = date('Y-m-d');
require_once show_template('header-advanced');
?>
<div class='panel-heading'>
    <h3 class='panel-title'>
        <span class='glyphicon glyphicon-option-vertical'></span>
        <strong>Metas por distribuidor</strong>
    </h3>
</div>
<div class='panel-body'>
    <div class='row'>
        <div class='col-sm-8 hidden-xs'>
            <div class='text-label'>Para agregar nuevas metas hacer clic en el siguiente botón: </div>
        </div>
        <div class='col-xs-12 col-sm-4 text-right'>
            <a href='?/metas_distribuidor/crear' class='btn btn-primary' data-toggle="tooltip" data-placement="top" title="Nueva Meta (Alt+N)"><i class='glyphicon glyphicon-plus'></i><span> Nuevo</span></a>
        </div>
    </div>
    <hr>
    <?php
    if ($Consulta) :
    ?>
        <table id="table" class="table table-bordered table-condensed table-striped table-hover table-xs">
            <thead>
                <tr class='active'>
                    <th class='text-nowrap'>#</th>
                    <th class='text-nowrap'>Distribuidor</th>
                    <th class='text-nowrap'>Presupuesto<?= escape($moneda); ?></th>
                    <th class='text-nowrap'>Ejecutado<?= escape($moneda); ?></th>
                    <th class='text-nowrap'>Avance(%)</th>
                    <th class='text-nowrap'>Por distribuir <?= escape($moneda); ?></th>
                    <th class='text-nowrap'>Distribuciones del día<?= escape($moneda); ?></th>
                    <th class='text-nowrap'>Clientes asignados del día</th>
                    <th class='text-nowrap'>Clientes activos</th>
                    <th class='text-nowrap'>Clientes inactivos</th>
                    <th class='text-nowrap'>Clientes no visitados</th>
                    <th class='text-nowrap'>Tendencia <?= escape($moneda) ?></th>
                    <th class='text-nowrap'>Tendencia (%)</th>
                    <th class='text-nowrap'>Fecha Inicial</th>
                    <th class='text-nowrap'>Fecha Final</th>
                    <th class='text-nowrap'>Opciones</th>
                </tr>
            </thead>
            <tfoot>
                <tr class='active'>
                    <th class='text-nowrap' data-datafilter-filter="true">#</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Distribuidor</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Presupuesto<?= escape($moneda); ?></th>
                    <th class='text-nowrap' data-datafilter-filter="true">Ejecutado<?= escape($moneda); ?></th>
                    <th class='text-nowrap' data-datafilter-filter="true">Avance(%)</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Por distribuir <?= escape($moneda); ?></th>
                    <th class='text-nowrap' data-datafilter-filter="true">Distribuciones del día<?= escape($moneda); ?></th>
                    <th class='text-nowrap' data-datafilter-filter="true">Clientes asignados del día</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Clientes activos</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Clientes inactivos</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Clientes no visitados</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Tendencia <?= escape($moneda) ?></th>
                    <th class='text-nowrap' data-datafilter-filter="true">Tendencia (%)</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Fecha Inicial</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Fecha Final</th>
                    <th class='text-nowrap' data-datafilter-filter="true">Opciones</th>
                </tr>
            </tfoot>
            <tbody>
                <?php
                foreach ($Consulta as $Fila => $Dato) :
                    $Conseguido=$db->query("SELECT IFNULL(SUM(monto_total),0)AS total FROM tmp_egresos WHERE anulado != 3 AND distribuidor_estado='ENTREGA' AND distribuidor_id='{$Dato['distribuidor_id']}' AND distribuidor_fecha  BETWEEN '{$Dato['fecha_inicio']}' AND '{$Dato['fecha_fin']}'")->fetch_first()['total'];
                    $porc = ($Conseguido*100)/$Dato['monto'];
                    $ventas_dia=$db->query("SELECT IFNULL(SUM(monto_total),0)AS total FROM tmp_egresos WHERE anulado != 3 AND distribuidor_estado='ENTREGA' AND distribuidor_id='{$Dato['distribuidor_id']}' AND distribuidor_fecha  = '{$hoy}'")->fetch_first()['total'];

                    // para sacar el los clientes asignados
                    $total_clientes = 0;
                    $rutas = $db->select('gps_rutas.*')->from('gps_asigna_distribucion as ad')
                                ->join('gps_rutas', 'ad.ruta_id = gps_rutas.id_ruta')
                                ->where('ad.distribuidor_id',$Dato['distribuidor_id'])
                                ->where('ad.fecha_ini >=', $Dato["fecha_inicio"])
                                ->where('ad.fecha_fin <=', $Dato["fecha_fin"])->fetch();
                    // echo $db->last_query();

                    $rutas1 = 0;
                    $rutas2 = 0;
                    foreach ($rutas as $key => $ruta) {
                        $polygon = explode('*',$ruta['coordenadas']);
                        foreach ($polygon as $nro => $poly) {
                            $aux = explode(',',$poly);
                            $aux2 = (round($aux[0],6)-0.000044).','.(round($aux[1],6)+0.00003);
                            $polygon[$nro] = str_replace(',', ' ', $aux2);
                        }
                        $polygon[0] = str_replace(',', ' ', $polygon[$nro]);
                        $pointLocation = new pointLocation();

                        // Obtiene los clientes
                        $clientes = $db->select('*')->from('inv_clientes')->fetch();
                        foreach($clientes as $cliente){
                            $aux2 = explode(',',$cliente['ubicacion']);
                            $aux3 = $aux2[0] + 0.00005;
                            $aux4 = $aux2[1] - 0.00003;
                            $point = $aux3.' '.$aux4;
                            $punto = $pointLocation->pointInPolygon($point, $polygon);
                            if($punto == 'dentro'){
                                $total_clientes = $total_clientes + 1;
                            }
                        }
                        $id_ruta = $ruta['id_ruta'];
                        // $rutas2a = $db->query("SELECT a.*, COUNT(id_egreso) as contador_no_ventas  FROM gps_rutas a LEFT JOIN (SELECT id_egreso, ruta_id FROM inv_egresos WHERE ruta_id > 0 AND fecha_egreso BETWEEN '{$Dato['fecha_inicio']}' AND '{$Dato['fecha_fin']}'  GROUP BY cliente_id, ruta_id) b ON b.ruta_id = a.id_ruta WHERE a.id_ruta = '$id_ruta' GROUP BY a.id_ruta ORDER BY fecha")->fetch_first();
                        // $rutas2a  = $db->query("SELECT a.*, COUNT(id_egreso) as contador_no_ventas  FROM gps_rutas a LEFT JOIN (SELECT id_egreso, ruta_id FROM tmp_egresos WHERE ruta_id > 0  AND distribuidor_fecha BETWEEN '{$Dato['fecha_inicio']}' AND '{$Dato['fecha_fin']}'  GROUP BY cliente_id, ruta_id) b ON b.ruta_id = a.id_ruta WHERE a.id_ruta = '$id_ruta' GROUP BY a.id_ruta ORDER BY fecha")->fetch_first();
                        $rutas2a = $db->query("SELECT a.*, COUNT(id_egreso) as contador_no_ventas
                                                FROM gps_asigna_distribucion a
                                                LEFT JOIN (SELECT id_egreso, ruta_id
                                                        FROM tmp_egresos
                                                        WHERE ruta_id > 0
                                                        AND distribuidor_fecha
                                                        BETWEEN '{$Dato['fecha_inicio']}' AND '{$Dato['fecha_fin']}'
                                                        AND distribuidor_estado='NO ENTREGA'
                                                        AND distribuidor_id='{$Dato['distribuidor_id']}'
                                                        GROUP BY cliente_id, ruta_id) b ON b.ruta_id = a.ruta_id
                                                WHERE a.ruta_id = '$id_ruta'
                                                GROUP BY a.ruta_id")->fetch_first();
                        // echo $db->last_query();
                        // echo json_encode($rutas2a); die();
                        // $rutas1a = $db->query("SELECT a.*, COUNT(id_egreso) as contador_ventas  FROM gps_rutas a LEFT JOIN (SELECT id_egreso, ruta_id FROM inv_egresos WHERE ruta_id > 0 AND fecha_egreso BETWEEN '{$Dato['fecha_inicio']}' AND '{$Dato['fecha_fin']}' AND tipo = 'Venta' GROUP BY cliente_id, ruta_id) b ON b.ruta_id = a.id_ruta WHERE a.id_ruta = '$id_ruta' GROUP BY a.id_ruta ORDER BY fecha")->fetch_first();
                        // $rutas1a = $db->query("SELECT a.*, COUNT(id_egreso) as contador_ventas  FROM gps_rutas a LEFT JOIN (SELECT id_egreso, ruta_id FROM tmp_egresos WHERE ruta_id > 0   AND distribuidor_fecha BETWEEN '{$Dato['fecha_inicio']}' AND '{$Dato['fecha_fin']}' AND tipo = 'Venta' GROUP BY cliente_id, ruta_id) b ON b.ruta_id = a.id_ruta WHERE a.id_ruta = '$id_ruta' GROUP BY a.id_ruta ORDER BY fecha")->fetch_first();
                        $rutas1a = $db->query("SELECT a.*, COUNT(id_egreso) as contador_ventas
                                                FROM gps_asigna_distribucion a
                                                LEFT JOIN (SELECT id_egreso, ruta_id
                                                        FROM tmp_egresos
                                                        WHERE ruta_id > 0
                                                        AND distribuidor_fecha
                                                        BETWEEN '{$Dato['fecha_inicio']}' AND '{$Dato['fecha_fin']}'
                                                        AND distribuidor_estado='ENTREGA'
                                                        AND distribuidor_id='{$Dato['distribuidor_id']}'
                                                        AND tipo = 'Venta'
                                                        GROUP BY cliente_id, ruta_id) b ON b.ruta_id = a.ruta_id
                                                WHERE a.ruta_id = '$id_ruta'
                                                GROUP BY a.ruta_id")->fetch_first();
                        // echo json_encode($rutas1a); die();
                        $rutas2 = $rutas2 + $rutas2a['contador_no_ventas'];
                        $rutas1 = $rutas1 + $rutas1a['contador_ventas'];
                    }


                    $fecha1= new DateTime($Dato['fecha_inicio']);
                    $fecha2= new DateTime($Dato['fecha_fin']);
                    $diff = $fecha1->diff($fecha2);
                    $quitar = ($diff->days)/7;
                    $dias = ($diff->days) - round($quitar);


                    $fechaA= new DateTime($Dato['fecha_inicio']);
                    $fechaA2= new DateTime(date('Y-m-d'));
                    $diffA = $fechaA->diff($fechaA2);
                    $quitarA = ($diffA->days)/7;
                    $dias_hoy = ($diffA->days) - round($quitarA);

                    $tendencia_bs = ($Conseguido / $dias_hoy)*$dias;
                    $tendencia_pc = ($tendencia_bs / $Dato['monto'])*100;
                ?>
                    <tr>
                        <td class='text-nowrap'><?= $Fila + 1 ?></td>
                        <td class='text-nowrap'><?= $Dato['nombres'].' '.$Dato['paterno'].' '.$Dato['materno'] ?></td>
                        <td class='text-nowrap text-right'><?= number_format($Dato['monto'] ,2) ?></td>
                        <td class='text-nowrap text-right'><?= number_format($Conseguido ,2) ?></td>
                        <td class='text-nowrap'><?= number_format($porc ,2) ?> %</td>
                        <td class='text-nowrap text-right'><?= number_format(($Dato['monto'] - $Conseguido) ,2) ?></td>
                        <td class='text-nowrap text-right'><?= number_format($ventas_dia ,2) ?></td>
                        <td class='text-nowrap text-right'><?= $total_clientes ?></td>
                        <td class='text-nowrap text-right'><?= $rutas1; ?></td>
                        <td class='text-nowrap text-right'><?= $rutas2; ?></td>
                        <td class='text-nowrap text-right'><?= ($total_clientes - ($rutas1+$rutas2) > 0)?($total_clientes - ($rutas1+$rutas2)):0 ?></td>
                        <td class='text-nowrap text-right'><?= number_format($tendencia_bs ,2) ?></td>
                        <td class='text-nowrap'><?= number_format($tendencia_pc ,2) ?> %</td>
                        <td class='text-nowrap'><?= $Dato['fecha_inicio'] ?></td>
                        <td class='text-nowrap'><?= $Dato['fecha_fin'] ?></td>
                        <td class='text-nowrap'>
                            <a href='?/metas_distribuidor/ver/<?= $Dato['id_meta'] ?>' data-toggle='tooltip' data-title='Ver Meta' data-ver='true'><i class='glyphicon glyphicon-search'></i></a>
                            <a href='?/metas_distribuidor/eliminar-<?= $Dato['id_meta'] ?>' data-toggle='tooltip' data-title='Eliminar Meta' data-eliminar='true'><i class='glyphicon glyphicon-trash'></i></a>
                        </td>
                    </tr>
                <?php
                endforeach;
                ?>
            </tbody>
        </table>
    <?php
    else :
    ?>
        <div class="alert alert-danger">
            <strong>Advertencia!</strong>
            <p>No existen metas registradas en la base de datos, para crear nuevas metas hacer clic en el botón nuevo o presionar las teclas <kbd>alt + n</kbd>.</p>
        </div>
    <?php
    endif;
    ?>
</div>
<script src='<?= js; ?>/jquery.dataTables.min.js'></script>
<script src='<?= js; ?>/dataTables.bootstrap.min.js'></script>
<script src='<?= js; ?>/jquery.form-validator.min.js'></script>
<script src='<?= js; ?>/jquery.form-validator.es.js'></script>
<script src='<?= js; ?>/jquery.maskedinput.min.js'></script>
<script src='<?= js; ?>/jquery.base64.js'></script>
<script src='<?= js; ?>/pdfmake.min.js'></script>
<script src='<?= js; ?>/vfs_fonts.js'></script>
<script src="<?= js; ?>/jquery.dataFilters.min.js"></script>
<script src='<?= js; ?>/moment.min.js'></script>
<script src='<?= js; ?>/moment.es.js'></script>
<script src='<?= js; ?>/bootstrap-datetimepicker.min.js'></script>
<script>
    $(document).on('click', '[data-eliminar]', function(e) {
        e.preventDefault();
        let fila = this.parentNode.parentNode;
        let url = $(this).attr('href');
        url = url.split('-');
        bootbox.confirm('Está seguro que desea eliminar esta meta?', function(result) {
            if (result) {
                $.ajax({
                    type: 'post',
                    dataType: 'json',
                    url: url[0],
                    data: {
                        'id_meta': url[1]
                    }
                }).done(function(ruta) {
                    if (ruta) {
                        $.notify({
                            message: 'La ruta fue registrada satisfactoriamente.'
                        }, {
                            type: 'success'
                        });
                        fila.parentNode.removeChild(fila);
                    } else {
                        $.notify({
                            message: 'Ocurrió un problema en el proceso, no se puedo guardar los datos, verifique si la se guardó parcialmente.'
                        }, {
                            type: 'danger'
                        });
                    }
                }).fail(function() {
                    $.notify({
                        message: 'Ocurrió un problema en el proceso, no se puedo guardar los datos, verifique si la se guardó parcialmente.'
                    }, {
                        type: 'danger'
                    });
                });
            }
        });
    });
    $(window).bind('keydown', function (e) {
		if (e.altKey || e.metaKey) {
			switch (String.fromCharCode(e.which).toLowerCase()) {
				case 'n':
					e.preventDefault();
					window.location = '?/metas/crear';
				break;
			}
		}
	});
	$(function () {
	   
    	var table = $('#table').DataFilter({
    		filter: true,
    		name: 'reporte_ventas_manuales',
    		reports: 'excel|word|pdf|html'
    	});
    	
    });
</script>
<?php require_once show_template('footer-advanced');
