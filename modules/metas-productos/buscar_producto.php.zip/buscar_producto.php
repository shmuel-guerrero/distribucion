<?php
    $Datos=$_POST['term'];
    $Datos=$db->query("SELECT id_producto,codigo,nombre
                    FROM inv_productos
                    WHERE codigo LIKE '%{$Datos}%' OR nombre LIKE '%{$Datos}%'
                    GROUP BY(nombre)
                    ORDER BY nombre ASC,codigo ASC
                    LIMIT 20")->fetch();
    $json=[];
    if($Datos):
        foreach($Datos as $Nro=>$Dato):
            $json[]=[
                'id'=>$Dato['id_producto'],
                'text'=>"{$Dato['nombre']} - {$Dato['codigo']}"];
        endforeach;
    endif;
    echo json_encode($json);