<?php
if(is_post()) {
    if (isset($_POST['id_user']) && isset($_POST['latitud']) && isset($_POST['longitud'])) {
        require config . '/database.php';

        $id_user = $_POST['id_user'];
        $latitud = $_POST['latitud'];
        $logitud = $_POST['longitud'];
        $fecha = date('Y-m-d');
        $hora = '*'.date('H:i:s');
        //$ubicacion
        $coordenada = '*'.$latitud.','.$logitud;
        $ubicacion = $db->select('*')->from('gps_seguimientos')->where('user_id',$id_user)->where('fecha_seguimiento',date('Y-m-d'))->fetch_first();
        if($ubicacion){
            $datos = array(
                'coordenadas' => $ubicacion['coordenadas'].$coordenada,
                'hora_seguimiento' => $ubicacion['hora_seguimiento'].$hora
            );
            $db->where(array('user_id' => $id_user, 'fecha_seguimiento' => $fecha))->update('gps_seguimientos',$datos);
        }else{
            $datos = array(
                'coordenadas' => $coordenada,
                'fecha_seguimiento' => $fecha,
                'hora_seguimiento' => $hora,
                'user_id' => $id_user
            );
            $id = $db->insert('gps_seguimientos',$datos);
        }


            $respuesta = array(
                'estado' => 's'
            );
            echo json_encode($respuesta);

    } else {
        echo json_encode(array('estado' => 'no llego uno de los datos'));
    }
}else{
    echo json_encode(array('estado' => 'no llego los datos'));
}
?>