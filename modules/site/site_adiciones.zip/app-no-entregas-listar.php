<?php

/**
 * FunctionPHP - Framework Functional PHP
 *
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
    // Verifica la existencia de datos
    if (isset($_POST['id_user'])) {
        // Importa la configuracion para el manejo de la base de datos
        require config . '/database.php';

        // Obtiene los datos
        $id_usuario = trim($_POST['id_user']);

        // Obtiene los usuarios que cumplen la condicion
        $usuario = $db->query("select id_user, id_empleado from sys_users LEFT JOIN sys_empleados ON persona_id = id_empleado where  id_user = '$id_usuario' and active = '1' limit 1")->fetch_first();

        // Verifica la existencia del usuario
        if ($usuario) {
            $total = $db->select('SUM(monto_total) as total, COUNT(cliente_id) as cont')->from('tmp_egresos')->where('distribuidor_id',$usuario['id_empleado'])->where('distribuidor_estado','ENTREGA')->where('estado',3)->fetch_first();
            $productos = $db->query('SELECT GROUP_CONCAT(b.cantidad, "-", b.unidad_id SEPARATOR "|" ) AS cantidades, GROUP_CONCAT(b.precio SEPARATOR "|" ) AS precios, SUM(a.monto_total) AS m_total,  c.*, b.*, c.unidad_id AS unidad_producto, d.categoria
                FROM tmp_egresos a
                LEFT JOIN tmp_egresos_detalles b ON a.id_tmp_egreso = b.tmp_egreso_id
                LEFT JOIN inv_productos c ON b.producto_id = c.id_producto
                LEFT JOIN inv_categorias d ON c.categoria_id = d.id_categoria
                WHERE a.estado = 3 AND a.distribuidor_id = '.$usuario['id_empleado'].' AND a.distribuidor_estado != "ENTREGA" AND a.distribuidor_estado != "VENTA" and b.promocion_id != 1
                GROUP BY c.id_producto ORDER BY d.categoria')->fetch();

            $devueltos = array();

            foreach($productos as $nro => $detalle){
                $cantidades = 0;
                $unid = explode('|', $detalle['cantidades']);
                $precios = explode('|', $detalle['precios']);
                if(count($unid)>1){
                    //si tiene mas unidades
                    $importe_t = 0;
                    foreach ($unid as $nro2 => $uni) {
                        $parte = explode('-', $uni);
                        $unidad = $parte[1];
                        $cantid = $parte[0];

                        $cantidades = $cantidades + $cantid;
                        // echo '//'.$total.'//-';
                        $importe = (int)($cantid/cantidad_unidad($db,$detalle['id_producto'],$unidad)) * $precios[$nro2];
                        $importe_t = $importe_t + $importe ;
                    }
                }else{
                    $parte = explode('-', $unid[0]);
                    $unidad = $parte[1];
                    $cantid = $parte[0];
                    $cantidades = $cantidades + $cantid;
                    //echo json_encode(cantidad_unidad($db,$detalle['id_producto'],$unidad));exit();
                    $importe = (int)($cantid/cantidad_unidad($db,$detalle['id_producto'],$unidad)) * $precios[0];
                    $importe_t = $importe;
                }
                $tipo_unidad = nombre_unidad($db,$detalle['unidad_producto']);
                $venta_directa = $db->select('sum(b.cantidad) as suma')->from('tmp_egresos a')->join('tmp_egresos_detalles b','b.egreso_id = a.id_egreso')->where('a.estadoe',0)->where('a.distribuidor_id',$usuario['id_empleado'])->where('b.producto_id',$detalle['id_producto'])->where('a.distribuidor_estado','VENTA')->fetch_first();
                if($venta_directa){
                    $sum = $venta_directa['suma'];
                }else{
                    $sum = 0;
                }
                $devueltos[$nro]['nombre'] = $detalle['nombre_factura'];
                $devueltos[$nro]['codigo'] = $detalle['codigo'];
                $devueltos[$nro]['id_producto'] = $detalle['id_producto'];
                $devueltos[$nro]['categoria'] = $detalle['categoria'];
                $devueltos[$nro]['imagen'] = ($detalle['imagen'] == '') ? url1 . imgs2 . '/image.jpg' : url1. productos2 . '/' . $detalle['imagen'];
                $devueltos[$nro]['cantidad'] = $cantidades - $sum;
                $devueltos[$nro]['unidad'] = $tipo_unidad;
                $devueltos[$nro]['id_unidad'] =$detalle['unidad_producto'];
                $devueltos[$nro]['precio'] = $detalle['precio'];
                $devueltos[$nro]['total'] = round($importe_t,2);

            }
            // Instancia el objeto
            $respuesta = array(
                'estado' => 's',
                'producto' => $devueltos
            );

            // Devuelve los resultados
            echo json_encode($respuesta);
        } else {
            // Devuelve los resultados
            echo json_encode(array('estado' => 'n'));
        }
    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'n'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'n'));
}

?>