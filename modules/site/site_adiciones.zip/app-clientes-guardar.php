<?php
if(is_post()) {
    if (isset($_POST['cliente']) && isset($_POST['telefono']) && isset($_POST['descripcion']) && isset($_POST['imagen']) && isset($_POST['id_user'])) {
        require config . '/database.php';
        require_once libraries . '/upload-class/class.upload.php';
        $usuario = $db->select('*')->from('sys_users a')->join('sys_empleados b','a.persona_id = b.id_empleado')->where('a.id_user',$_POST['id_user'])->fetch_first();
        if($usuario['fecha'] != date('Y-m-d')){
        // if(true){
            $cliente = $_POST['cliente'];
            $nombre_factura = $_POST['nombre_factura'];
            $nit = $_POST['nit'];
            $telefono = $_POST['telefono'];
            $direccion = $_POST['direccion'];
            $descripcion = $_POST['descripcion'];
            $ubicacion = $_POST['latitud'].','.$_POST['longitud'];
            $imagen = $_POST['imagen'];
            $tipo = $_POST['tipo_cliente'];
            $correo = ($_POST['correo']!='')?$_POST['correo']:'';
            //$ubicacion

            $imagen_final = md5(secret . random_string() . 'miimagen');
            $extension = 'jpg';
            $ruta = files . '/tiendas/' . $imagen_final . '.' . $extension;

            $n_imagen = $imagen_final.'.'.$extension;

            file_put_contents($ruta, base64_decode($imagen));

            $datos = array(
                'cliente' => $cliente,
                'nombre_factura' => $nombre_factura,
                'nit' => $nit,
                'estado' => 'si',
                'telefono' => $telefono,
                'direccion' => $direccion,
                'descripcion' => $descripcion,
                'email' => $correo,
                'ubicacion' => $ubicacion,
                'imagen' => $n_imagen,
                'tipo' => $tipo
            );
            // $ver = $db->select('*')->from('inv_clientes')->where(array('cliente' => $cliente, 'nombre_factura' => $nombre_factura, 'nit' => $nit, 'direccion' => $direccion))->fetch_first();
            // if(!$ver){
            $id = $db->insert('inv_clientes',$datos);
            // }
            if($id){
                $clientee[0] = array(
                    'estado' => 'v',
                    'id_cliente' => $id,
                    'cliente' => $cliente,
                    'nombre_factura' => $nombre_factura,
                    'nit' => $nit,
                    'telefono' => $telefono,
                    'direccion' => $direccion,
                    'descripcion' => $descripcion,
                    'latitud' => $_POST['latitud'],
                    'longitud' => $_POST['longitud'],
                    'imagen' => $ruta,
                    'tipo_cliente' => $tipo,
                    'estadoe' => 0
                );
                $respuesta = array(
                    'estado' => 's',
                    'cliente' => $clientee
                );
                echo json_encode($respuesta);
            }else{
                echo json_encode(array('estado' => 'no guardo'));
            }
        }else{
            echo json_encode(array('estado' => 'Inactivo'));
        }
    } else {
        echo json_encode(array('estado' => 'no llego uno de los datos'));
    }
}else{
    echo json_encode(array('estado' => 'no llego los datos'));
}
?>