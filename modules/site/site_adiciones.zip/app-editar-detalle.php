<?php

/**
 * FunctionPHP - Framework Functional PHP
 *
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
    // Verifica la existencia de datos
    if (isset($_POST['id_user']) && isset($_POST['id_detalle']) && isset($_POST['cantidad']) && isset($_POST['unidad_id']) && $_POST['cantidad'] != 0) {
        // Importa la configuracion para el manejo de la base de datos
        require config . '/database.php';

        $empleado = $db->select('persona_id')->from('sys_users')->where('id_user',$_POST['id_user'])->fetch_first();
        $id_user = $empleado['persona_id'];
        $id_detalle = $_POST['id_detalle'];
        $cantidad = $_POST['cantidad'];
        $id_unidad = $_POST['unidad_id'];


        //buscamos el detalle y sus datos
        $detalle = $db->select('*, id_detalle as tmp_egreso_id')->from('inv_egresos_detalles')->where('id_detalle',$id_detalle)->fetch_first();
        if($detalle['promocion_id'] != 0 && $detalle['promocion_id'] != ''){
            echo json_encode(array('estado' => 'promocion'));
        }
        else{
            $id_egreso = $detalle['egreso_id'];

            //detalles del egreso
            $egreso = $db->select('b.*, b.fecha_egreso as distribuidor_fecha , b.hora_egreso as distribuidor_hora, b.almacen_id as distribuidor_estado, b.almacen_id as distribuidor_id, b.estadoe as estado')->from('inv_egresos b')->where('b.id_egreso',$id_egreso)->fetch_first();

            //detalles productos
            $producto = $db->select('*')->from('inv_productos')->where('id_producto',$detalle['producto_id'])->fetch_first();

            $precio = $detalle['precio'];
            $precio2 = precio_unidad($db,$detalle['id_producto'],$id_unidad);
            $monto_sub_total = $cantidad * $precio;
            $cantidad_detalle = $detalle['cantidad'] / cantidad_unidad($db, $detalle['producto_id'], $id_unidad);
            //
            // echo json_encode($detalle);exit();

            //////////////////////////////////////////////////////////////////////////
            $Lotes=$db->query("SELECT producto_id,lote,unidad_id
                                FROM inv_egresos_detalles AS ed
                                LEFT JOIN inv_unidades AS u ON ed.unidad_id=u.id_unidad
                                WHERE id_detalle='$id_detalle'")->fetch();
            foreach($Lotes as $Fila=>$Lote):
                $IdProducto=$Lote['producto_id'];
                $UnidadId=$Lote['unidad_id'];
                $LoteGeneral=explode(',',$Lote['lote']);

                for($i=0;$i<=count($LoteGeneral);++$i):
                    $SubLote=explode('-',$LoteGeneral[$i]);
                    $Lot=$SubLote[0];
                    $Cantidad=$SubLote[1];
                    $DetalleIngreso=$db->query("SELECT id_detalle,lote_cantidad
                                            FROM inv_ingresos_detalles
                                            WHERE producto_id='{$IdProducto}' AND lote='{$Lot}'
                                            LIMIT 1")->fetch_first();
                    $CantidadAux=$Cantidad;
                    $Datos=[
                        'lote_cantidad'=>(strval($DetalleIngreso['lote_cantidad'])+strval($CantidadAux)),
                    ];
                    $db->where('id_detalle', $DetalleIngreso['id_detalle'])->where('lote', $Lot)->update('inv_ingresos_detalles',$Datos);
                endfor;
            endforeach;

            $db->delete()->from('inv_egresos_detalles')->where('id_detalle', $id_detalle)->execute(); // eliminamos el detalle
            // Guarda Historial
            $data = array(
                'fecha_proceso' => date("Y-m-d"),
                'hora_proceso' => date("H:i:s"),
                'proceso' => 'u',
                'nivel' => 'l',
                'direccion' => '?/site/app-editar-detalle',
                'detalle' => 'Se elimino inventario egreso detalle con identificador numero' . $id_detalle,
                'usuario_id' => $id_user
            );
            $db->insert('sys_procesos', $data);
            // -------------------------------*------------------------------
            $unidad3 = $id_unidad;
            $cant_uni = cantidad_unidad($db, $detalle['producto_id'], $unidad3) * $cantidad;
            $Lote='';
            $CantidadAux=$cant_uni;
            $Detalles=$db->query("SELECT id_detalle,cantidad,lote,lote_cantidad
                                FROM inv_ingresos_detalles
                                WHERE producto_id='{$detalle["producto_id"]}' AND lote_cantidad>0
                                ORDER BY id_detalle ASC")->fetch();
            foreach($Detalles as $Fila=>$Detalle):
                if($CantidadAux>=$Detalle['lote_cantidad']):
                    $Datos=[
                        'lote_cantidad'=>0,
                    ];
                    $Cant=$Detalle['lote_cantidad'];
                    $db->where('id_detalle', $Detalle['id_detalle'])->update('inv_ingresos_detalles',$Datos);
                    $CantidadAux=$CantidadAux-$Detalle['lote_cantidad'];
                    $Lote.=$Detalle['lote'].'-'.$Cant.',';
                elseif($CantidadAux>0):
                    $Datos=[
                        'lote_cantidad'=>$Detalle['lote_cantidad']-$CantidadAux,
                    ];
                    $Cant=$CantidadAux;
                    $db->where('id_detalle', $Detalle['id_detalle'])->update('inv_ingresos_detalles',$Datos);
                    $CantidadAux=$CantidadAux-$Detalle['lote_cantidad'];
                    $Lote.=$Detalle['lote'].'-'.$Cant.',';
                else:
                    break;
                endif;
            endforeach;
            $Lote=trim($Lote,',');
            // echo json_encode($Lote); die();
            // -------------------------------*------------------------------
            // $detalle_nuevo = array(
            //     'cantidad' => $cant_uni,
            //     'unidad_id' => $unidad3,
            //     'precio' => $precio,
            //     'descuento' => $detalle['descuento'],
            //     'producto_id' => $detalle["id_producto"],
            //     'egreso_id' => $$detalle["egreso_id"],
            //     'lote'=>$Lote
            // );

            // // Guarda la informacion
            // $id = $db->insert('inv_egresos_detalles', $detalle);
            // // Guarda Historial
            // $data = array(
            //     'fecha_proceso' => date("Y-m-d"),
            //     'hora_proceso' => date("H:i:s"),
            //     'proceso' => 'c',
            //     'nivel' => 'l',
            //     'direccion' => '?/site/app-editar-detalle',
            //     'detalle' => 'Se creo inventario egreso detalle con identificador numero ' . $id,
            //     'usuario_id' => $_SESSION[user]['id_user']
            // );

            // $db->insert('sys_procesos', $data);
            //////////////////////////////////////////////////////////////////////////





            if($id_unidad == $detalle['unidad_id']){
                if($cantidad < $cantidad_detalle){
                    //reducimos la cantidad y el precio

                    $monto_total = $egreso['monto_total'] - (($cantidad_detalle - $cantidad) * $precio);
                    $aux = $cantidad * cantidad_unidad($db, $detalle['producto_id'], $id_unidad);

                    $db->where('id_egreso',$id_egreso)->update('inv_egresos',array('monto_total' => $monto_total));
                    // $db->where('id_detalle',$id_detalle)->update('inv_egresos_detalles',array('cantidad' => $aux));
                    $detalle_nuevo = array(
                        'cantidad' => $aux,
                        'unidad_id' => $unidad3,
                        'precio' => $precio,
                        'descuento' => $detalle['descuento'],
                        'producto_id' => trim($detalle['producto_id']),
                        'egreso_id' => $id_egreso,
                        'lote'=>$Lote
                    );

                    // echo json_encode($Lote); die();
                    // Guarda la informacion
                    $id = $db->insert('inv_egresos_detalles', $detalle_nuevo);

                    //datos tmp
                    $egreso['monto_total'] = (($cantidad_detalle - $cantidad) * $precio);
                    $egreso['nro_registros'] = 1;
                    $egreso['distribuidor_fecha'] = date('Y-m-d');
                    $egreso['distribuidor_hora'] = date('H:i:s');
                    $egreso['distribuidor_estado'] = 'DEVUELTO';
                    $egreso['distribuidor_id'] = $id_user;
                    $egreso['estado'] = 3;
                    $id = $db->insert('tmp_egresos', $egreso);

                    $detalle['tmp_egreso_id'] = $id;
                    $detalle['cantidad'] = $detalle['cantidad'] - ($cantidad * cantidad_unidad($db, $detalle['producto_id'], $id_unidad));
                    $detalle['unidad_id'] = $id_unidad;
                    $detalle['precio'] = $precio;
                    $id = $db->insert('tmp_egresos_detalles', $detalle);

                }elseif($cantidad == $detalle['cantidad']){
                    //no se realiza ningun cambio
                }
            }else{
                $monto_total_ant = ($detalle['cantidad'] / cantidad_unidad($db, $detalle['producto_id'], $detalle['unidad_id'])) * $precio;
                $otro_precio = precio_unidad($db, $detalle['producto_id'], $id_unidad);
                $otra_unidad = cantidad_unidad($db, $detalle['producto_id'], $id_unidad);
                $monto_total = $egreso['monto_total'] - $monto_total_ant + ($cantidad * $otro_precio);
                $db->where('id_egreso',$id_egreso)->update('inv_egresos',array('monto_total' => $monto_total));
                // $db->where('id_detalle',$id_detalle)->update('inv_egresos_detalles',array('cantidad' => $cantidad*$otra_unidad, 'precio' => $otro_precio, 'unidad_id' => $id_unidad));
                $detalle_nuevo = array(
                    'cantidad' => $cantidad*$otra_unidad,
                    'unidad_id' => $unidad3,
                    'precio' => $otro_precio,
                    'descuento' => $detalle['descuento'],
                    'producto_id' => trim($detalle['producto_id']),
                    'egreso_id' => $id_egreso,
                    'lote'=>$Lote
                );
                // echo json_encode($Lote); die();
                // Guarda la informacion
                $id = $db->insert('inv_egresos_detalles', $detalle_nuevo);

                //detales de tmp
                $egreso['monto_total'] = $cantidad * $otro_precio;
                $egreso['nro_registros'] = 1;
                $egreso['distribuidor_fecha'] = date('Y-m-d');
                $egreso['distribuidor_hora'] = date('H:i:s');
                $egreso['distribuidor_estado'] = 'DEVUELTO';
                $egreso['distribuidor_id'] = $id_user;
                $egreso['estado'] = 3;
                $id = $db->insert('tmp_egresos', $egreso);

                $detalle['tmp_egreso_id'] = $id;
                $detalle['cantidad'] = $detalle['cantidad'] - ($cantidad * $otra_unidad);
                $detalle['unidad_id'] = $id_unidad;
                $detalle['precio'] = $otro_precio;
                $id = $db->insert('tmp_egresos_detalles', $detalle);

            }
            $respuesta = array(
                'estado' => 's'
            );
            echo json_encode($respuesta);
        }
    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'no llega el id usuario'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'no llega ningun dato'));
}

?>