<?php

/**
 * FunctionPHP - Framework Functional PHP
 *
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
    // Verifica la existencia de datos
    if (isset($_POST['id_user'])) {
        // Importa la configuracion para el manejo de la base de datos
        require config . '/database.php';
        $id_user = $_POST['id_user'];
        $dia = date('w');
        $ruta = $db->select('*')->from('sys_users a')->join('gps_rutas b','a.persona_id = b.empleado_id')->where('a.id_user',$id_user)->where('b.dia',$dia)->fetch_first();

        //$ruta = $db->select('*')->from('gps_rutas a')->join('sys_user b','a.empleado_id = b.persona_id')->where('b.id_user',$id_user)->fetch_first();
        if($ruta['coordenadas']){
            $coordenadas = explode('*',$ruta['coordenadas']);
            $coor = array();
            $sw = false;
            foreach($coordenadas as $nro => $coordenada){
                $parte = explode(',',$coordenadas[$nro]);
                if($sw){
                    array_push($coor, array('latitud'=>(double)($parte[0] - 0.00005),'longitud'=>(double)($parte[1] + 0.00003)));
                }else{
                    $sw = true;
                }
            }
            $sw = false;
            $parte = explode(',',$coordenadas[1]);
            array_push($coor, array('latitud'=>(double)($parte[0] - 0.00005),'longitud'=>(double)($parte[1] + 0.00003)));        
            
            $respuesta = array(
                'estado' => 's',
                'id_ruta' => $ruta['id_ruta'],
                'coordenadas' => $coor
            );
            echo json_encode($respuesta);
        }else{

            // Instancia el objeto
            $respuesta = array(
                'id_ruta' => 0,
                'coordenadas' => '',
                'estado' => 'n'
            );

            // Devuelve los resultados
            echo json_encode($respuesta);
        }
    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'no llega el id usuario'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'no llega ningun dato'));
}

?>