<?php

if(is_post()) {
    if (isset($_POST['id_cliente']) && isset($_POST['id_user'])) {
        require config . '/database.php';
        //identificamos el usuario vendedor o distribuidor
        $rol = $db->select('a.rol_id, a.persona_id, b.fecha')->from('sys_users a')->join('sys_empleados b','a.persona_id = b.id_empleado')->where('a.id_user',$_POST['id_user'])->fetch_first();
        $id_user = $rol['persona_id'];
        if($rol['fecha'] != date('Y-m-d')){
            if( $rol['rol_id'] != 4 ){
                $nit = $_POST['nit'];
                $nombre_cliente = $_POST['cliente'];
                $id_cliente = $_POST['id_cliente'];
                $id_user = $_POST['id_user'];
                $ubicacion = $_POST['ubicacion'];
                $observacion = $_POST['prioridad'];
                $hora_ini = $_POST['hora_inicial'];
                $hora_fin = $_POST['hora_final'];
                $motivo = $_POST['motivo_id'];

                $horaInicio = new DateTime($hora_fin);
                $horaTermino = new DateTime($hora_ini);

                $duracion = $horaInicio->diff($horaTermino);
                $duracion = $duracion->format('%H:%I:%s');

                $empleado = $db->select('persona_id')->from('sys_users')->where('id_user',$id_user)->fetch_first();
                $id_empleado = $empleado['persona_id'];

                //buscamos la ruta que tiene
                $ruta = $db->select('id_ruta')->from('gps_rutas')->where('empleado_id',$id_empleado)->where('dia',date('w'))->fetch_first();

                $egreso = array(
                    'fecha_egreso' => date('Y-m-d'),
                    'hora_egreso' => date('H:i:s'),
                    'descripcion' => 'No se realizo ninguna venta',
                    'cliente_id' => $id_cliente,
                    'nit_ci' => $nit,
                    'nombre_cliente' => strtoupper($nombre_cliente),
                    'empleado_id' => $id_empleado,
                    'coordenadas' => $ubicacion,
                    'motivo_id' => $motivo,
                    'estadoe' => 1,
                    'duracion' => $duracion,
                    'tipo' => 'NO VENTA',
                    'provisionado' => 'N',
                    'nro_factura' => 0,
                    'nro_autorizacion' => 0,
                    'codigo_control' => 0,
                    'fecha_limite' => '0000-00-00',
                    'monto_total' => 0,
                    'nro_registros' => 0,
                    'dosificacion_id' => 0,
                    'almacen_id' => 0,
                    'ruta_id' => $ruta['id_ruta']
                );

                $id = $db->insert('inv_egresos',$egreso);

                if($id){
                    $respuesta = array(
                        'estado' => 's',
                        'estadoe' => 1
                    );
                    echo json_encode($respuesta);
                }else{
                    echo json_encode(array('estado' => 'no guardo'));
                }
            }else{
                $verifica = $db->select('*')->from('tmp_egresos')->where('distribuidor_estado','NO ENTREGA')->where('estado',3)->where('cliente_id',$_POST['id_cliente'])->fetch_first();
                if(!$verifica){
                    $motivo = $_POST['motivo_id'];
                    $id_cliente = $_POST['id_cliente'];

                    $fecha = $db->select('a.fecha')->from('sys_empleados a')->join('inv_egresos b','a.id_empleado = b.empleado_id')->where('b.cliente_id',$id_cliente)->where('b.estadoe',2)->fetch_first();

                    if($fecha['fecha'] == date('Y-m-d')){
                        $egresos = $db->select('b.*, b.fecha_egreso as distribuidor_fecha , b.hora_egreso as distribuidor_hora, b.almacen_id as distribuidor_estado, b.almacen_id as distribuidor_id, b.estadoe as estado')->from('inv_egresos b')->where('b.fecha_egreso <=',date('Y-m-d'))->where('b.cliente_id',$_POST['id_cliente'])->where('b.estadoe',2)->fetch();
                    }
                    else{
                        $egresos = $db->select('b.*, b.fecha_egreso as distribuidor_fecha , b.hora_egreso as distribuidor_hora, b.almacen_id as distribuidor_estado, b.almacen_id as distribuidor_id, b.estadoe as estado')->from('inv_egresos b')->where('b.fecha_egreso <',date('Y-m-d'))->where('b.cliente_id',$_POST['id_cliente'])->where('b.estadoe',2)->fetch();
                    }

                    foreach($egresos as $nro2 => $egreso){
                        $egreso['distribuidor_fecha'] = date('Y-m-d');
                        $egreso['distribuidor_hora'] = date('H:i:s');
                        $egreso['distribuidor_estado'] = 'NO ENTREGA';
                        $egreso['motivo_id'] = $_POST['motivo_id'];
                        $egreso['distribuidor_id'] = $id_user;
                        $egreso['estado'] = 3;
                        $egreso['estadoe'] = 4;
                        $id_egreso = $egreso['id_egreso'];

                        $id = $db->insert('tmp_egresos', $egreso);
                        $db->delete()->from('inv_egresos')->where('id_egreso',$id_egreso)->limit(1)->execute();

                        $detalles = $db->select('a.*, a.id_detalle as tmp_egreso_id')->from('inv_egresos_detalles a')->where('a.egreso_id',$id_egreso)->fetch();


                        /////////////////////////////////////////////////////////////////////
                        $Lotes=$db->query("SELECT producto_id,lote,unidad_id
                                    FROM inv_egresos_detalles AS ed
                                    LEFT JOIN inv_unidades AS u ON ed.unidad_id=u.id_unidad
                                    WHERE egreso_id='{$id_egreso}'")->fetch();
                        foreach($Lotes as $Fila=>$Lote):
                            $IdProducto=$Lote['producto_id'];
                            $UnidadId=$Lote['unidad_id'];
                            $LoteGeneral=explode(',',$Lote['lote']);
                            for($i=0;$i<count($LoteGeneral);++$i):
                                $SubLote=explode('-',$LoteGeneral[$i]);
                                $Lot=$SubLote[0];
                                $Cantidad=$SubLote[1];
                                $DetalleIngreso=$db->query("SELECT id_detalle,lote_cantidad
                                                            FROM inv_ingresos_detalles
                                                            WHERE producto_id='{$IdProducto}' AND lote='{$Lot}'
                                                            LIMIT 1")->fetch_first();
                                $Condicion=[
                                        'id_detalle'=>$DetalleIngreso['id_detalle'],
                                        'lote'=>$Lot,
                                    ];
                                $CantidadAux=$Cantidad;
                                $Datos=[
                                        'lote_cantidad'=>(strval($DetalleIngreso['lote_cantidad'])+strval($CantidadAux)),
                                    ];
                                $db->where($Condicion)->update('inv_ingresos_detalles',$Datos);
                            endfor;
                        endforeach;
                        /////////////////////////////////////////////////////////////////////


//                echo json_encode($detalles);exit();
                        foreach($detalles as $nro => $detalle){
                            $detalle['tmp_egreso_id'] = $id;
                            $id_detalle = $detalle['id_detalle'];
                            $db->insert('tmp_egresos_detalles', $detalle);
                            $db->delete()->from('inv_egresos_detalles')->where('id_detalle',$id_detalle)->limit(1)->execute();
                        }
                    }
                    $respuesta = array(
                        'estado' => 's',
                        'estadoe' => 4
                    );
                    echo json_encode($respuesta);
                }else{
                    echo json_encode(array('estado' => 'nonono'));
                }
            }
        }else{
            echo json_encode(array('estado' => 'Inactivo'));
        }
//
    } else {
        echo json_encode(array('estado' => 'no llego uno de los datos'));
    }
}else{
    echo json_encode(array('estado' => 'no llego los datos'));
}
?>