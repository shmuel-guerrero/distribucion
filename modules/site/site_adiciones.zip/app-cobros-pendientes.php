<?php

/**
 * FunctionPHP - Framework Functional PHP
 *
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
    // Verifica la existencia de datos
    if (isset($_POST['id_user']) && isset($_POST['id_cliente'])) {
        // Importa la configuracion para el manejo de la base de datos
        require config . '/database.php';
        $cliente_id = $_POST['id_cliente'];

        // Obtiene los usuarios que cumplen la condicion
        $usuario = $db->from('sys_users')->join('sys_empleados','persona_id = id_empleado')->where('id_user',$_POST['id_user'])->fetch_first();
        $emp = $usuario['id_empleado'];

        //buscar si es vendedor o distribuidor
        $deudas = $db->select('b.id_pago, a.fecha_egreso, a.tipo, sum(CASE WHEN c.estado = 0 THEN FORMAT(c.monto, 2) ELSE 0 END) as pendiente, COUNT(c.id_pago_detalle) as nro_cuotas , a.monto_total')->from('inv_egresos a')
            ->join('inv_pagos b','b.movimiento_id = a.id_egreso')
            ->join('inv_pagos_detalles c','c.pago_id = b.id_pago')
            ->where('a.plan_de_pagos','si')->where('a.cliente_id',$_POST['id_cliente'])->group_by('a.id_egreso')->fetch();
        foreach($deudas as $nro => $deuda){
            $detalles = $db->select('*')->from('inv_pagos_detalles')->where('pago_id',$deuda['id_pago'])->fetch();
            foreach($detalles as $nro2 => $detalle){
                $detalles[$nro2]['id_cliente'] = $cliente_id;
            }
            $deudas[$nro]['detalle'] = $detalles;
        }
        $respuesta = array(
            'estado' => 's',
            'deudas' => $deudas
        );
        echo json_encode($respuesta);
    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'no llega el id usuario'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'no llega ningun dato'));
}

?>