<?php
/**
 * SimplePHP - Simple Framework PHP
 *
 * @package  SimplePHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica si es una peticion post
if (is_post()) 
{
	// Verifica la existencia de los datos enviados
	
    if (isset($_POST['id_user']) && isset($_POST['id_meta']))
    { 
        require config . '/database.php';
        $id_user        = $_POST['id_user'];
        $tipo_meta      = $_POST['id_meta'];
        $empleado = $db->select('*')->from('sys_users a')->join('sys_empleados b','b.id_empleado = a.persona_id')->where('a.id_user',$id_user)->fetch_first();
        if($tipo_meta == 1){
            $vendedores = $db->select('a.id_meta,a.monto, a.fecha_inicio, a.fecha_fin, b.nombres as nombre')->from('inv_meta a')->join('sys_empleados b','b.id_empleado = a.empleado_id')->where('a.empleado_id',$empleado['id_empleado'])->where('a.fecha_inicio<=',date('Y-m-d'))->where('a.fecha_fin>=',date('Y-m-d'))->fetch();
            foreach($vendedores as $nrop => $vendedor){
                $ini = ($vendedor['fecha_inicio'])?$vendedor['fecha_inicio']:'no tiene';
                $fin = ($vendedor['fecha_fin'])?$vendedor['fecha_fin']:'no tiene';
                $meta = ($vendedor['monto'])?$vendedor['monto']:'no tiene';
                if($ini != 'no tiene' && $fin != 'no tiene' && $meta != 'no tiene'){
                    $total = $db->select('sum(monto_total) as total')->from('inv_egresos')->where(array('empleado_id' => $empleado['id_empleado'], 'fecha_egreso>=' => $ini, 'fecha_egreso<=' => $fin, 'estadoe!='=>2))->fetch_first()['total'];
                    $total = ($total)?$total:0;
                    $porcen = ($total * 100) / $meta;
                }else{
                    $total = 'no tiene';
                    $porcen = 'no tiene';
                }
                $vendedores[$nrop]['total_p'] = $total;
                $vendedores[$nrop]['porcentaje_p'] = $porcen;
            }
            $respuesta = array(
                'estado' => 's',
                'metas' => $vendedores
                
            );
            echo json_encode($respuesta);
        }elseif($tipo_meta == 2){
            $productos =  $db->select('a.id_meta_producto as id_meta, a.monto, a.fecha_inicio, a.fecha_fin, b.nombre')->from('inv_meta_producto a')->join('inv_productos b','b.id_producto = a.producto_id')->where('a.fecha_inicio<=',date('Y-m-d'))->where('a.fecha_fin>=',date('Y-m-d'))->fetch();
            foreach($productos as $nrop => $producto){
                $ini = ($producto['fecha_inicio'])?$producto['fecha_inicio']:'no tiene';
                $fin = ($producto['fecha_fin'])?$producto['fecha_fin']:'no tiene';
                $meta = ($producto['monto'])?$producto['monto']:'no tiene';
                if($ini != 'no tiene' && $fin != 'no tiene' && $meta != 'no tiene'){
                    $total = $db->select('sum(monto_total) as total')->from('inv_egresos')->where(array('empleado_id' => $empleado['id_empleado'], 'fecha_egreso>=' => $ini, 'fecha_egreso<=' => $fin, 'estadoe!='=>2))->fetch_first()['total'];
                    $total = ($total)?$total:0;
                    $porcen = ($total * 100) / $meta;
                }else{
                    $total = 'no tiene';
                    $porcen = 'no tiene';
                }
                $productos[$nrop]['total_p'] = $total;
                $productos[$nrop]['porcentaje_p'] = $porcen;
            }
            $respuesta = array(
                'estado' => 's',
                'metas' => $productos
                
            );
            echo json_encode($respuesta);
        }elseif($tipo_meta == 3){
            $categorias =  $db->select('a.id_meta_categoria as id_meta, a.monto, a.fecha_inicio, a.fecha_fin, b.categoria as nombre')->from('inv_meta_categoria a')->join('inv_categorias b','b.id_categoria = a.categoria_id')->where('a.fecha_inicio<=',date('Y-m-d'))->where('a.fecha_fin>=',date('Y-m-d'))->fetch();
            foreach($categorias as $nrop => $categoria){
                $ini = ($categoria['fecha_inicio'])?$categoria['fecha_inicio']:'no tiene';
                $fin = ($categoria['fecha_fin'])?$categoria['fecha_fin']:'no tiene';
                $meta = ($categoria['monto'])?$categoria['monto']:'no tiene';
                if($ini != 'no tiene' && $fin != 'no tiene' && $meta != 'no tiene'){
                    $total = $db->select('sum(monto_total) as total')->from('inv_egresos')->where(array('empleado_id' => $empleado['id_empleado'], 'fecha_egreso>=' => $ini, 'fecha_egreso<=' => $fin, 'estadoe!='=>2))->fetch_first()['total'];
                    $total = ($total)?$total:0;
                    $porcen = ($total * 100) / $meta;
                }else{
                    $total = 'no tiene';
                    $porcen = 'no tiene';
                }
                $categorias[$nrop]['total_p'] = $total;
                $categorias[$nrop]['porcentaje_p'] = $porcen;
            }
            
            $respuesta = array(
                'estado' => 's',
                'metas' => $categorias
                
            );
            echo json_encode($respuesta);
        }elseif($tipo_meta == 4){
            // $empleado['id_empleado']
            $distros = $db->select("m.id_meta,m.monto,m.fecha_inicio,m.fecha_fin,m.distribuidor_id,e.nombres as nombre,e.paterno,e.materno, e.id_empleado")
                          ->from('inv_metas_distribuidor AS m')
                          ->join('sys_empleados AS e', 'e.id_empleado=m.distribuidor_id', 'left')
                          ->where('m.distribuidor_id', $empleado['id_empleado'])
                          ->fetch();
            // $Conseguido=$db->query("SELECT IFNULL(SUM(monto_total),0)AS total FROM tmp_egresos WHERE distribuidor_id='{$Consulta['distribuidor_id']}' AND distribuidor_estado='ENTREGA' AND distribuidor_fecha BETWEEN '{$Consulta['fecha_inicio']}' AND '{$Consulta['fecha_fin']}'")->fetch_first()['total'];
            
            foreach($distros as $nrop => $distro){
                $ini = ($distro['fecha_inicio'])?$distro['fecha_inicio']:'no tiene';
                $fin = ($distro['fecha_fin'])?$distro['fecha_fin']:'no tiene';
                $meta = ($distro['monto'])?$distro['monto']:'no tiene';
                if($ini != 'no tiene' && $fin != 'no tiene' && $meta != 'no tiene'){
                    $total = $db->select('sum(monto_total) as total')
                                ->from('tmp_egresos')
                                ->where(array('distribuidor_id' => $empleado['id_empleado'], 'distribuidor_fecha>=' => $ini, 'distribuidor_fecha<=' => $fin, 'distribuidor_estado'=>'ENTREGA'))
                                ->fetch_first()['total'];
                    $total = ($total)?$total:0;
                    $porcen = ($total * 100) / $meta;
                }else{
                    $total = 'no tiene';
                    $porcen = 'no tiene';
                }
                $distros[$nrop]['total_p'] = $total;
                $distros[$nrop]['porcentaje_p'] = $porcen;
            }
            
            $respuesta = array(
                'estado' => 's',
                'metas' => $distros
            );
            echo json_encode($respuesta);
        }else{
             // Instancia el objeto
            $respuesta = array(
                'estado' => 'no exite metas'
            );
            // Devuelve los resultados
            echo json_encode($respuesta);
        }
        
    } else {
        // Instancia el objeto
        $respuesta = array(
            'estado' => 'no llego algun dato'
        );

        // Devuelve los resultados
        echo json_encode($respuesta);
	}
} else {
    echo json_encode(array('estado' => 'no llega ningun dato'));
}
?>