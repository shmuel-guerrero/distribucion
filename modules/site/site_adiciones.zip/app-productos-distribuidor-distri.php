<?php

/**
 * FunctionPHP - Framework Functional PHP
 *
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
    // Verifica la existencia de datos
    if (isset($_POST['id_egreso']) && isset($_POST['id_user']) && isset($_POST['id_cliente'])) {
        // Importa la configuracion para el manejo de la base de datos
        require config . '/database.php';
        $cliente_id = $_POST['id_cliente'];
        $egreso_id = $_POST['id_egreso'];

        // Obtiene los usuarios que cumplen la condicion
        $usuario = $db->from('sys_users')->join('sys_empleados','persona_id = id_empleado')->where('id_user',$_POST['id_user'])->fetch_first();
        $emp = $usuario['id_empleado'];

        //buscar si es vendedor o distribuidor
        // $productos = $db->query('SELECT DISTINCT b.*,c.id_producto, c.promocion, c.codigo, c.nombre_factura as nombre, c.precio_sugerido, c.precio_sugerido as stock, d.categoria, e.unidad, c.unidad_id AS unidad_idp, b.unidad_id AS unidad_ide, e.unidad AS total, a.id_egreso
        //     FROM gps_asigna_distribucion g
        //     LEFT JOIN (SELECT x.* FROM gps_asigna_distribucion y LEFT JOIN gps_rutas x ON y.ruta_id = x.id_ruta WHERE y.distribuidor_id = '. $emp .') f ON g.ruta_id = f.id_ruta
        //     LEFT JOIN sys_empleados w ON f.empleado_id = w.id_empleado
        //     LEFT JOIN inv_egresos a ON f.id_ruta = a.ruta_id
        //     LEFT JOIN inv_egresos_detalles b ON a.id_egreso = b.egreso_id
        //     LEFT JOIN inv_productos c ON b.producto_id = c.id_producto
        //     LEFT JOIN inv_categorias d ON c.categoria_id = d.id_categoria
        //     LEFT JOIN inv_unidades e ON c.unidad_id = e.id_unidad
        //     WHERE a.estadoe = 3

        //     and a.id_egreso = ' . $egreso_id )->fetch(); // (a.fecha_egreso <= w.fecha OR a.fecha_egreso < CURDATE())

            
            // AND a.cliente_id = '. $cliente_id .' 
            // AND g.distribuidor_id = '. $emp .' AND g.estado = 1 
            // AND a.grupo = "" AND b.promocion_id != 1 

        $productos = $db->query('SELECT DISTINCT b.*,c.id_producto, c.promocion, c.codigo, c.nombre_factura as nombre, c.precio_sugerido, c.precio_sugerido as stock, d.categoria, e.unidad, c.unidad_id AS unidad_idp, b.unidad_id AS unidad_ide, e.unidad AS total, a.id_egreso
            FROM gps_asigna_distribucion g
            LEFT JOIN inv_egresos a ON g.grupo_id = a.grupo
            LEFT JOIN inv_egresos_detalles b ON a.id_egreso = b.egreso_id
            LEFT JOIN inv_productos c ON b.producto_id = c.id_producto
            LEFT JOIN inv_categorias d ON c.categoria_id = d.id_categoria
            LEFT JOIN inv_unidades e ON c.unidad_id = e.id_unidad
            WHERE a.estadoe = 3
            
            and a.id_egreso = ' . $egreso_id
            )->fetch(); // AND a.fecha_egreso <= CURDATE()'

            // AND a.cliente_id = '. $cliente_id .' 
            // AND g.distribuidor_id = '. $emp .' 
            // AND g.estado = 1 AND a.grupo != "" 

        // $productos = array_merge($productos, $productos2);
        // echo json_encode($productos);exit();
        //$dis = $db->select('c.*, c.ubicacion as latitud, c.ubicacion as longitud, b.fecha_egreso, b.estadoe, b.empleado_id')->from('gps_asigna_distribucion a')->join('inv_egresos b','a.empleado_id = b.empleado_id')->join('inv_clientes c','b.cliente_id = c.id_cliente')->where('a.distribuidor_id',$emp)->where('a.estado',1)->where('b.estadoe>',1)->where('b.fecha_egreso<',date('Y-m-d'))->group_by('b.cliente_id')->fetch();
        $total = number_format(0, 2, '.', '');
        $egresos = array();
        if($productos){
            foreach ($productos as $nro => $producto) {
                if($producto['unidad_idp']!=$producto['unidad_ide']){
                    $unidad = $db->select('*')->from('inv_asignaciones a')->join('inv_unidades b', 'a.unidad_id = b.id_unidad')->where('producto_id',$producto['id_producto'])->where('unidad_id',$producto['unidad_ide'])->fetch_first();
                    $productos[$nro]['unidad'] = $unidad['unidad'];
                    $productos[$nro]['precio'] = $unidad['otro_precio'];
                    $productos[$nro]['stock'] = $producto['cantidad'];                    //$productos[$nro]['cantidad'] = $producto['cantidad'];
                    $productos[$nro]['cantidad'] = $producto['cantidad']/$unidad['cantidad_unidad'];
                    $productos[$nro]['total'] = number_format(($unidad['otro_precio'] * ($producto['cantidad']/$unidad['cantidad_unidad'])), 2, '.', '');
                    $total = $total + $productos[$nro]['total'];
                    $productos[$nro]['id_detalle'] = (int)$producto['id_detalle'];
                    $productos[$nro]['egreso_id'] = (int)$producto['egreso_id'];
                }
                else{
                    $productos[$nro]['stock'] = $producto['cantidad'];
                    $productos[$nro]['total'] = number_format(($producto['precio'] * $producto['cantidad']), 2, '.', '');
                    $total = $total + $productos[$nro]['total'];
                    $productos[$nro]['id_detalle'] = (int)$producto['id_detalle'];
                    $productos[$nro]['egreso_id'] = (int)$producto['egreso_id'];
                }
                $egresos[$nro] = $productos[$nro]['id_egreso'];
            }
            $respuesta = array(
                'estado' => 'd',
                'total' => number_format($total, 2, '.', ''),
                'egresos' => $egresos,
                'cliente' => $productos
            );
            echo json_encode($respuesta);
        }else{
            // Instancia el objeto
            $respuesta = array(
                'estado' => 'no exite productos'
            );
            // Devuelve los resultados
            echo json_encode($respuesta);
        }
    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'no llega el id usuario'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'no llega ningun dato'));
}

?>