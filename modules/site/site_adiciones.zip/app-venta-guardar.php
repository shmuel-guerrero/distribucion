<?php
date_default_timezone_set('America/La_Paz');
if(is_post()) {
    if (isset($_POST['id_cliente']) && isset($_POST['id_user'])) {
        require config . '/database.php';

        $nit = $_POST['nit'];
        $nombre_cliente = $_POST['nombre_factura'];
        $id_cliente = $_POST['id_cliente'];
        $productos = (isset($_POST['productos'])) ? $_POST['productos'] : array();
        $cantidades = (isset($_POST['cantidades'])) ? $_POST['cantidades'] : array();
        $sw = 0;
        $verifica = $db->select('*')->from('inv_egresos')->where('cliente_id',$id_cliente)->where('fecha_egreso',date('Y-m-d'))->fetch_first();
        $id_user = $_POST['id_user'];
        $empleado = $db->select('persona_id,almacen_id')->from('sys_users')->where('id_user',$id_user)->fetch_first();
        $id_almacen = $empleado['almacen_id'];
        if(!$verifica){
            foreach($productos as $key2 => $producto){
                $prod = $db->query("SELECT p.id_producto, p.promocion, z.id_asignacion, z.unidad_id, z.unidade, z.cantidad2, p.descripcion, p.imagen, p.codigo, p.nombre_factura as nombre, p.nombre_factura, p.cantidad_minima, p.precio_actual, IFNULL(e.cantidad_ingresos, 0) AS cantidad_ingresos, (IFNULL(s.cantidad_egresos, 0) + IFNULL(sp.cantidad_promocion, 0) + IFNULL(spr.cantidad_venta_promo, 0)) AS cantidad_egresos, u.unidad, u.sigla, c.categoria
					FROM inv_productos p
					LEFT JOIN (SELECT d.producto_id, SUM(d.cantidad) AS cantidad_ingresos
						   FROM inv_ingresos_detalles d
						   LEFT JOIN inv_ingresos i ON i.id_ingreso = d.ingreso_id
						   WHERE i.almacen_id = '$id_almacen' GROUP BY d.producto_id) AS e ON e.producto_id = p.id_producto
					LEFT JOIN (SELECT d.producto_id, SUM(d.cantidad) AS cantidad_egresos
						   FROM inv_egresos_detalles d LEFT JOIN inv_egresos e ON e.id_egreso = d.egreso_id
						   WHERE e.almacen_id = '$id_almacen' AND e.anulado != 3 AND d.promocion_id < 2 GROUP BY d.producto_id) AS s ON s.producto_id = p.id_producto
                    LEFT JOIN (SELECT d.producto_id, SUM(d.cantidad) AS cantidad_venta_promo
							FROM inv_egresos_detalles d 
                            LEFT JOIN inv_egresos e ON e.id_egreso = d.egreso_id
                            LEFT JOIN inv_productos pr ON pr.id_producto = d.promocion_id
						   	WHERE e.almacen_id = '$id_almacen' AND  d.promocion_id > 2 AND e.anulado != 3 AND pr.fecha_limite < CURDATE() GROUP BY d.producto_id) AS spr ON spr.producto_id = p.id_producto
                    LEFT JOIN (SELECT d.producto_id, SUM(d.cantidad*a.cantidad) AS cantidad_promocion
						    FROM inv_ingresos_detalles a 
                            LEFT JOIN inv_ingresos b on b.id_ingreso = a.ingreso_id 
                            INNER JOIN inv_promociones d ON d.id_promocion = a.producto_id
                            INNER JOIN inv_productos c ON c.id_producto = d.id_promocion
                            INNER JOIN inv_productos e ON e.id_producto = d.producto_id
                            WHERE b.almacen_id = '$id_almacen' AND e.fecha_limite > CURDATE() GROUP BY d.producto_id) AS sp ON sp.producto_id = p.id_producto
					LEFT JOIN inv_unidades u ON u.id_unidad = p.unidad_id LEFT JOIN inv_categorias c ON c.id_categoria = p.categoria_id
					LEFT JOIN (SELECT w.producto_id, GROUP_CONCAT(w.id_asignacion SEPARATOR '|') AS id_asignacion, GROUP_CONCAT(w.unidad_id SEPARATOR '|') AS unidad_id, GROUP_CONCAT(w.cantidad_unidad,')',w.unidad,':',w.otro_precio SEPARATOR '&') AS unidade, GROUP_CONCAT(w.cantidad_unidad SEPARATOR '*') AS cantidad2
					   FROM (SELECT *
							FROM inv_asignaciones q
								  LEFT JOIN inv_unidades u ON q.unidad_id = u.id_unidad
										 ORDER BY u.unidad DESC) w GROUP BY w.producto_id ) z ON p.id_producto = z.producto_id
                                         WHERE p.id_producto = ".$producto)->fetch_first();
                if(($prod['cantidad_ingresos']-$prod['cantidad_egresos']) < $cantidades[$key2]){
                    $sin_stock[$sw] = $prod;
                    $sw = $sw + 1;
                }
            }
            if($sw < 1){
                $nombres = (isset($_POST['nombres'])) ? $_POST['nombres'] : array();
                $unidad = (isset($_POST['unidad'])) ? $_POST['unidad']: array();
                $precios = (isset($_POST['precios'])) ? $_POST['precios'] : array();
                $promociones = (isset($_POST['promocion'])) ? $_POST['promocion'] : array();
                $nro_registros = count($productos);
                $monto_total = $_POST['monto_total'];
                $des_venta = $_POST['descripcion_venta'];
                $id_user = $_POST['id_user'];
//        $duracion = $_POST['duracion'];
                $ubicacion = $_POST['ubicacion'];
                $observacion = $_POST['prioridad'];
                $hora_ini = $_POST['hora_inicial'];
                $hora_fin = $_POST['hora_final'];

                $horaInicio = new DateTime($hora_fin);
                $horaTermino = new DateTime($hora_ini);

                $duracion = $horaInicio->diff($horaTermino);
                $duracion = $duracion->format('%H:%I:%s');

                $empleado = $db->select('persona_id')->from('sys_users')->where('id_user',$id_user)->fetch_first();
                $id_empleado = $empleado['persona_id'];

                //buscamos la ruta que tiene
                $ruta = $db->select('id_ruta')->from('gps_rutas')->where('empleado_id',$id_empleado)->where('dia',date('w'))->fetch_first();

                ///////////////////////////////////////////////////////////////////////////
                $DatosEgresoI=[];
                $monto_totalA=$monto_total;
                $DescuentoMonto=0;
                $DescuentoPorcentaje=0;
                $Fecha=date('Y-m-d');
                $Promociones=$db->query("SELECT id_promocion,tipo,min_promo,descuento_promo,monto_promo,item_promo FROM inv_promociones_monto WHERE '{$Fecha}'>=fecha_ini AND '{$Fecha}'<=fecha_fin AND (tipo='3' OR tipo='2' OR tipo='4')")->fetch();
                if($Promociones):
                    foreach($Promociones as $Fila=>$Promocion):
                        if($_POST['monto_total']>=$Promocion['min_promo']):
                            switch($Promocion['tipo']):
                                case 2:
                                    $DescuentoMonto+=$Promocion['monto_promo'];
                                    $monto_totalA=$monto_totalA-$Promocion['monto_promo'];
                                    break;
                                case 3:
                                    $DescuentoPorcentaje+=$Promocion['descuento_promo'];
                                    $porcentaje=round((0.01*$Promocion['descuento_promo']),Redondeo);
                                    $Aux=round(($monto_total*$porcentaje),Redondeo);
                                    $monto_totalA=$monto_totalA-$Aux;
                                    break;
                                case 4:
                                    //1--Creme 30ml-- 4.800--Unidad--2--0
                                    $ProductoI=explode('--',$Promocion['item_promo']);
                                    $IdUnidad=$db->select('id_unidad')
                                        ->from('inv_unidades')
                                        ->where(array('unidad' => $ProductoI[3]))
                                        ->fetch_first();
                                    $DatosEgresoI[]=[
                                        'precio'=>$ProductoI[2],//o 0
                                        'unidad_id'=>$IdUnidad['id_unidad'],
                                        'cantidad'=>$ProductoI[4],
                                        'descuento'=>'100',
                                        'producto_id'=>$ProductoI[0],
                                        'egreso_id'=>1,
                                        'promocion_id'=>$Promocion['id_promocion'],
                                        'asignacion_id'=>'0'
                                    ];
                                    break;
                            endswitch;
                        endif;
                    endforeach;
                endif;
                //////////////////////////////////////////////////////////////////


                // Obtiene el numero de nota
                $nro_factura = $db->query("select MAX(nro_factura) + 1 as nro_factura from inv_egresos where tipo = 'Venta' and provisionado = 'S'")->fetch_first();
                $nro_factura = $nro_factura['nro_factura'];
                $prom = 0;
                $a = 0; $b = 0;
                foreach($productos as $nro2 => $elemento2){
                    $aux = $db->select('*')->from('inv_productos')->where('id_producto',$productos[$nro2])->fetch_first();
                    if($aux['grupo']!=''){
                        $a = $a + $precios[$nro2]*$cantidades[$nro2];
                        $b = $b + 1;
                    }
                }
                $monto_total = $monto_total - $a;

                if(($nro_registros - $b) != 0) {
                    $con = $db->select('*')->from('inv_egresos')->where(array('fecha_egreso' => date('Y-m-d'),'cliente_id' => $id_cliente))->fetch_first();
                    if($con){
                    }else{
                        if($_POST['fecha_pago_inicial'] != ''){
                            $egreso = array(
                                'fecha_egreso' => date('Y-m-d'),
                                'hora_egreso' => date('H:i:s'),
                                'tipo' => 'Venta',
                                'provisionado' => 'S',
                                'descripcion' => 'Venta de productos con preventa',
                                'nro_factura' => $nro_factura,
                                'nro_autorizacion' => '',
                                'codigo_control' => '',
                                'fecha_limite' => '0000-00-00',
                                'monto_total' => $monto_total,
                                'cliente_id' => $id_cliente,
                                'nit_ci' => $nit,
                                'nombre_cliente' => $nombre_cliente,
                                'nro_registros' => $nro_registros - $b,
                                'dosificacion_id' => 0,
                                'almacen_id' => $almacen_id,
                                'empleado_id' => $id_empleado,
                                'coordenadas' => $ubicacion,
                                'observacion' => $observacion,
                                'estadoe' => $estadoe,
                                'ordenes_salidas_id' => $id_salida,
                                'duracion' => $duracion,
                                'descripcion_venta' => $des_venta,
                                'ruta_id' => $ruta['id_ruta'],
                                'plan_de_pagos' => 'si'
                            );
                            $id = $db->insert('inv_egresos', $egreso);
                            
                            //cuentas por cobrar
                            $monto_total        = $monto_total;
                            $nombre_cliente     = $nombre_cliente;
                            $pago_inicial       = $_POST['monto_pago_inicial'];
                            $cuota_dos          = $_POST['monto_cuota_dos'];
                            $cuota_tres         = $_POST['monto_cuota_tres'];
                            $id_egreso          = $id;
                            $empleado_id        = $id_empleado;
                    
                            $fecha_pago_inicial = trim($_POST['fecha_pago_inicial']);
                            $fecha_pago_inicial = date("Y-m-d", strtotime(str_replace('/','-',$fecha_pago_inicial)));
                            $fecha_cuota_dos    = trim($_POST['fecha_cuota_dos']);
                            $fecha_cuota_dos = date("Y-m-d", strtotime(str_replace('/','-',$fecha_cuota_dos)));
                            $fecha_cuota_tres   = trim($_POST['fecha_cuota_tres']);
                            $fecha_cuota_tres = date("Y-m-d", strtotime(str_replace('/','-',$fecha_cuota_tres)));

                            $detalle            = $_POST['motivo'];
                            $nro_cuota          = $_POST['nro_cuotas'];
        
                            $id_salida = $id_salida;
                            $fechas = array($fecha_pago_inicial, $fecha_cuota_dos, $fecha_cuota_tres);
                            $cuotas = array($pago_inicial,$cuota_dos,$cuota_tres);
                            $monto_total_cuotas = $pago_inicial + $cuota_dos + $cuota_tres;
                            if($monto_total_cuotas != $monto_total){
                                $cuota_tres = $monto_total - $pago_inicial - $cuota_dos;
                                $cuotas[2] = $cuota_tres;
                            }
                            $monto_total_cuotas = $pago_inicial + $cuota_dos + $cuota_tres;
                            if($monto_total<=$monto_total_cuotas){
                                $fecha_format=(isset($fechas[0])) ? $fechas[0]: "00-00-0000";
                                $vfecha=explode("-",$fecha_format);
                                $fecha_format=$vfecha[0]."-".$vfecha[1]."-".$vfecha[2];
                                $ingresoPlan = array (
                                    'movimiento_id' => $id_egreso,
                                    'tipo' => 'Egreso'
                                );
                                // Guarda la informacion del ingreso general
                                $ingreso_id_plan = $db->insert('inv_pagos', $ingresoPlan);
                                //inserta en cronograma
                                $datos_c = array(
                                    'fecha' => $fecha_format,
                                    'periodo' =>'trimestral',
                                    'detalle' => $detalle,
                                    'monto'=> $monto_total
                                );
            
                                $id_cronograma = $db->insert('cronograma', $datos_c);
            
                                if($cuotas[0]!=''){
                                    $fecha_format = (isset($fechas[0]) && $fechas[0]!='') ? $fechas[0]: "00-00-0000";
                                    $vfecha       = explode("-",$fecha_format);
                                    $fecha_format = $vfecha[0]."-".$vfecha[1]."-".$vfecha[2];
                                    $detallePlan = array(
                                        'pago_id'   => $ingreso_id_plan,
                                        'fecha'     => $fecha_format,
                                        'monto'     => (isset($cuotas[0])) ? $cuotas[0]: 0,
                                        'estado'    => 1,
                                        'fecha_pago'=> $fecha_format,
                                        'tipo_pago' => 'efectivo',
                                        'nro_cuota' => 1,
                                        'empleado_id' => $empleado_id,
                                        'ordenes_salidas_id' => $id_salida
                                    );
                                    $db->insert('inv_pagos_detalles', $detallePlan);
            
                                    //Inserta en cronograma detalle
                                    $datos_cron_det = array(
                                        'cronograma_id' => $id_cronograma,
                                        'fecha'         => $fecha_format,
                                        'estado'        => 1,
                                        'fecha_pago'    => $fecha_format,
                                        'tipo_pago'     => "efectivo",
                                        'detalle'       => $detalle,
                                        'empleado_id'   => $empleado_id,
                                        'monto'          => (isset($cuotas[0])) ? $cuotas[0]: 0
                                    );
                                    $db->insert('cronograma_cuentas', $datos_cron_det);
                                }
                                if($cuotas[1]!='' && $cuotas[1]!=0){
                                    $fecha_format = (isset($fechas[1]) && $fechas[1]!='') ? $fechas[1]: "00-00-0000";
                                    $vfecha       = explode("-",$fecha_format);
                                    $fecha_format = $vfecha[0]."-".$vfecha[1]."-".$vfecha[2];
                                    $detallePlan = array(
                                        'pago_id'   => $ingreso_id_plan,
                                        'fecha'     => $fecha_format,
                                        'monto'     => (isset($cuotas[1])) ? $cuotas[1]: 0,
                                        'estado'    => 0,
                                        'fecha_pago'=> $fecha_format,
                                        'tipo_pago' => 'cuotas',
                                        'nro_cuota' => 2,
                                        'empleado_id' => $empleado_id,
                                        'ordenes_salidas_id' => $id_salida
                                    );
                                    $db->insert('inv_pagos_detalles', $detallePlan);
            
                                    //Inserta en cronograma detalle
                                    $datos_cron_det = array(
                                        'cronograma_id' => $id_cronograma,
                                        'fecha'         => $fecha_format,
                                        'estado'        => 0,
                                        'fecha_pago'    => $fecha_format,
                                        'tipo_pago'     => "cuotas",
                                        'detalle'       => $detalle,
                                        'empleado_id'   => $empleado_id,
                                        'monto'          => (isset($cuotas[1])) ? $cuotas[1]: 0
                                    );
                                    $db->insert('cronograma_cuentas', $datos_cron_det);
                                }
                                if($cuotas[2]!='' && $cuotas[2]!=0){
                                    $fecha_format = (isset($fechas[2]) && $fechas[2]!='') ? $fechas[2]: "00-00-0000";
                                    $vfecha       = explode("-",$fecha_format);
                                    $fecha_format = $vfecha[0]."-".$vfecha[1]."-".$vfecha[2];
                                    $detallePlan = array(
                                        'pago_id'   => $ingreso_id_plan,
                                        'fecha'     => $fecha_format,
                                        'monto'     => (isset($cuotas[2])) ? $cuotas[2]: 0,
                                        'estado'    => 0,
                                        'fecha_pago'=> $fecha_format,
                                        'tipo_pago' => 'cuotas',
                                        'nro_cuota' => 3,
                                        'empleado_id' => $empleado_id,
                                        'ordenes_salidas_id' => $id_salida
                                    );
                                    $db->insert('inv_pagos_detalles', $detallePlan);
            
                                    //Inserta en cronograma detalle
                                    $datos_cron_det = array(
                                        'cronograma_id' => $id_cronograma,
                                        'fecha'         => $fecha_format,
                                        'estado'        => 0,
                                        'fecha_pago'    => $fecha_format,
                                        'tipo_pago'     => "cuotas",
                                        'detalle'       => $detalle,
                                        'empleado_id'   => $empleado_id,
                                        'monto'          => (isset($cuotas[2])) ? $cuotas[2]: 0
                                    );
                                    $db->insert('cronograma_cuentas', $datos_cron_det);
                                }
                            }
                        }else{
                            $egreso = array(
                                'fecha_egreso' => date('Y-m-d'),
                                'hora_egreso' => date('H:i:s'),
                                'tipo' => 'Venta',
                                'provisionado' => 'S',
                                'descripcion' => 'Venta de productos con preventa',
                                'nro_factura' => $nro_factura,
                                'nro_autorizacion' => '',
                                'codigo_control' => '',
                                'fecha_limite' => '0000-00-00',
                                'monto_total' => $monto_total,
                                'cliente_id' => $id_cliente,
                                'nit_ci' => $nit,
                                'nombre_cliente' => $nombre_cliente,
                                'nro_registros' => $nro_registros - $b,
                                'dosificacion_id' => 0,
                                'almacen_id' => 1,
                                'empleado_id' => $id_empleado,
                                'coordenadas' => $ubicacion,
                                'observacion' => $observacion,
                                'estadoe' => 2,
                                'duracion' => $duracion,
                                'descripcion_venta' => $des_venta,
                                'ruta_id' => $ruta['id_ruta']
                            );
                            $id = $db->insert('inv_egresos', $egreso);
                        }
                    }
                }
                // Recorre los productos
                foreach ($precios as $nro => $elemento) {
                    $id_unidade=$db->select('*')->from('inv_asignaciones a')->join('inv_unidades u','a.unidad_id=u.id_unidad')->where(array('u.unidad' => $unidad[$nro], 'a.producto_id' => $productos[$nro]))->fetch_first();
                    if($id_unidade){
                        $id_unidad = $id_unidade['id_unidad'];
                        $cantidad = $cantidades[$nro]*$id_unidade['cantidad_unidad'];
                    }else{
                        $id_uni = $db->select('id_unidad')->from('inv_unidades')->where('unidad',$unidad[$nro])->fetch_first();
                        $id_unidad = $id_uni['id_unidad'];
                        $cantidad = $cantidades[$nro];
                    }
                    $aux = $db->select('*')->from('inv_productos')->where('id_producto',$productos[$nro])->fetch_first();
                    if($aux['grupo'] == '' && $monto_total != 0){
                        if($promociones[$nro] != ''){

                            /////////////////////////////////////////////////////////////////////////////////////////
                            $Lote='';
                            $CantidadAux=$cantidad;
                            $Detalles=$db->query("SELECT id_detalle,cantidad,lote,lote_cantidad FROM inv_ingresos_detalles WHERE producto_id='$productos[$nro]' AND lote_cantidad>0 ORDER BY id_detalle ASC")->fetch();
                            foreach($Detalles as $Fila=>$Detalle):
                                if($CantidadAux>=$Detalle['lote_cantidad']):
                                    $Datos=[
                                        'lote_cantidad'=>0,
                                    ];
                                    $Cant=$Detalle['lote_cantidad'];
                                elseif($CantidadAux>0):
                                    $Datos=[
                                        'lote_cantidad'=>$Detalle['lote_cantidad']-$CantidadAux,
                                    ];
                                    $Cant=$CantidadAux;
                                else:
                                    break;
                                endif;
                                $Condicion=[
                                        'id_detalle'=>$Detalle['id_detalle'],
                                    ];
                                $db->where($Condicion)->update('inv_ingresos_detalles',$Datos);
                                $CantidadAux=$CantidadAux-$Detalle['lote_cantidad'];
                                $Lote.=$Detalle['lote'].'-'.$Cant.',';
                            endforeach;
                            $Lote=trim($Lote,',');
                            /////////////////////////////////////////////////////////////////////////////////////////
                            // Forma el detalle
                            $prod = $productos[$nro];
                            $promos = $db->select('producto_id, precio, unidad_id, cantidad, descuento , id_promocion as egreso_id, cantidad as promocion_id')
                                        ->from('inv_promociones')->where('id_promocion', $prod)->fetch();
                            $detalle = array(
                                'cantidad' => $cantidades[$nro],
                                'precio' => $precios[$nro],
                                'descuento' => 0,
                                'unidad_id' => 11,
                                'producto_id' => $productos[$nro],
                                'egreso_id' => $id,
                                'promocion_id' => 1,
                                'lote'=>$Lote
                            );
                            // Guarda la informacion
                            $db->insert('inv_egresos_detalles', $detalle);
                            foreach ($promos as $key => $promo) {
                                /////////////////////////////////////////////////////////////////////////////////////////
                                $Lote='';
                                $CantidadAux=$promo['cantidad'] * $cantidades[$nro];
                                $prodpromo = $promo['producto_id'];
                                $Detalles=$db->query("SELECT id_detalle,cantidad,lote,lote_cantidad FROM inv_ingresos_detalles WHERE producto_id='$prodpromo' AND lote_cantidad>0 ORDER BY id_detalle ASC")->fetch();
                                foreach($Detalles as $Fila=>$Detalle):
                                    if($CantidadAux>=$Detalle['lote_cantidad']):
                                        $Datos=[
                                            'lote_cantidad'=>0,
                                        ];
                                        $Cant=$Detalle['lote_cantidad'];
                                    elseif($CantidadAux>0):
                                        $Datos=[
                                            'lote_cantidad'=>$Detalle['lote_cantidad']-$CantidadAux,
                                        ];
                                        $Cant=$CantidadAux;
                                    else:
                                        break;
                                    endif;
                                    $Condicion=[
                                            'id_detalle'=>$Detalle['id_detalle'],
                                        ];
                                    $db->where($Condicion)->update('inv_ingresos_detalles',$Datos);
                                    $CantidadAux=$CantidadAux-$Detalle['lote_cantidad'];
                                    $Lote.=$Detalle['lote'].'-'.$Cant.',';
                                endforeach;
                                $Lote=trim($Lote,',');
                                /////////////////////////////////////////////////////////////////////////////////////////
                                $promo['lote'] = $Lote;
                                $promo['egreso_id'] = $id;
                                $promo['promocion_id'] = $productos[$nro];
                                $promo['cantidad'] = $promo['cantidad'] * $cantidades[$nro];
                                // Guarda la informacion
                                $db->insert('inv_egresos_detalles', $promo);
                            }
                        }else{
                            /////////////////////////////////////////////////////////////////////////////////////////
                            $Lote='';
                            $CantidadAux=$cantidad;
                            $Detalles=$db->query("SELECT id_detalle,cantidad,lote,lote_cantidad FROM inv_ingresos_detalles WHERE producto_id='$productos[$nro]' AND lote_cantidad>0 ORDER BY id_detalle ASC")->fetch();
                            foreach($Detalles as $Fila=>$Detalle):
                                if($CantidadAux>=$Detalle['lote_cantidad']):
                                    $Datos=[
                                        'lote_cantidad'=>0,
                                    ];
                                    $Cant=$Detalle['lote_cantidad'];
                                elseif($CantidadAux>0):
                                    $Datos=[
                                        'lote_cantidad'=>$Detalle['lote_cantidad']-$CantidadAux,
                                    ];
                                    $Cant=$CantidadAux;
                                else:
                                    break;
                                endif;
                                $Condicion=[
                                        'id_detalle'=>$Detalle['id_detalle'],
                                    ];
                                $db->where($Condicion)->update('inv_ingresos_detalles',$Datos);
                                $CantidadAux=$CantidadAux-$Detalle['lote_cantidad'];
                                $Lote.=$Detalle['lote'].'-'.$Cant.',';
                            endforeach;
                            $Lote=trim($Lote,',');
                            /////////////////////////////////////////////////////////////////////////////////////////
                            // Forma el detalle
                            $detalle = array(
                                'cantidad' => $cantidad,
                                'precio' => $precios[$nro],
                                'descuento' => 0,
                                'unidad_id' => $id_unidad,
                                'producto_id' => $productos[$nro],
                                'egreso_id' => $id,
                                'lote'=>$Lote
                            );
                            // Guarda la informacion
                            $db->insert('inv_egresos_detalles', $detalle);
                        }
                    }else{
                        $nro_factura2 = $db->query("select count(id_egreso) + 1 as nro_factura from inv_egresos where tipo = 'Venta' and provisionado = 'S'")->fetch_first();
                        $nro_factura2 = $nro_factura2['nro_factura'];
                        $egreso2 = array(
                            'fecha_egreso' => date('Y-m-d'),
                            'hora_egreso' => date('H:i:s'),
                            'tipo' => 'Venta',
                            'provisionado' => 'S',
                            'descripcion' => 'Venta de productos con preventa',
                            'nro_factura' => $nro_factura2,
                            'nro_autorizacion' => '',
                            'codigo_control' => '',
                            'fecha_limite' => '0000-00-00',
                            'monto_total' => $precios[$nro]*$cantidades[$nro],
                            'cliente_id' => $id_cliente,
                            'nit_ci' => $nit,
                            'nombre_cliente' => $nombre_cliente,
                            'nro_registros' => 1,
                            'dosificacion_id' => 0,
                            'almacen_id' => 1,
                            'empleado_id' => $id_empleado,
                            'coordenadas' => $ubicacion,
                            'observacion' => $observacion,
                            'estadoe' => 2,
                            'duracion' => $duracion,
                            'grupo' => $aux['grupo'],
                            'ruta_id' => $ruta['id_ruta']
                        );
                        $id2 = $db->insert('inv_egresos',$egreso2);


                        /////////////////////////////////////////////////////////////////////////////////////////
                        $Lote='';
                        $CantidadAux=$cantidad;
                        $Detalles=$db->query("SELECT id_detalle,cantidad,lote,lote_cantidad FROM inv_ingresos_detalles WHERE producto_id='$productos[$nro]' AND lote_cantidad>0 ORDER BY id_detalle ASC")->fetch();
                        foreach($Detalles as $Fila=>$Detalle):
                            if($CantidadAux>=$Detalle['lote_cantidad']):
                                $Datos=[
                                    'lote_cantidad'=>0,
                                ];
                                $Cant=$Detalle['lote_cantidad'];
                            elseif($CantidadAux>0):
                                $Datos=[
                                    'lote_cantidad'=>$Detalle['lote_cantidad']-$CantidadAux,
                                ];
                                $Cant=$CantidadAux;
                            else:
                                break;
                            endif;
                            $Condicion=[
                                    'id_detalle'=>$Detalle['id_detalle'],
                                ];
                            $db->where($Condicion)->update('inv_ingresos_detalles',$Datos);
                            $CantidadAux=$CantidadAux-$Detalle['lote_cantidad'];
                            $Lote.=$Detalle['lote'].'-'.$Cant.',';
                        endforeach;
                        $Lote=trim($Lote,',');
                        /////////////////////////////////////////////////////////////////////////////////////////

                        $detalle2 = array(
                            'cantidad' => $cantidad,
                            'precio' => $precios[$nro],
                            'descuento' => 0,
                            'unidad_id' => $id_unidad,
                            'producto_id' => $productos[$nro],
                            'egreso_id' => $id2,
                            'lote'=>$Lote
                        );
                        $db->insert('inv_egresos_detalles', $detalle2);
                    }
                }
                if($id || $id2){
                    for($i=0;$i<count($DatosEgresoI);++$i):
                        $producto_id = $DatosEgresoI[$i]['producto_id'];
                        $Detalles = $db->query("SELECT id_detalle,cantidad,lote,lote_cantidad FROM inv_ingresos_detalles WHERE producto_id='$producto_id' AND lote_cantidad>0 ORDER BY id_detalle ASC")->fetch();
                        $Lote = '';
                        $CantidadAux = $DatosEgresoI[$i]['cantidad'];
                        foreach ($Detalles as $Fila => $Detalle) :
                            if ($CantidadAux >= $Detalle['lote_cantidad']) :
                                $Datos = [
                                    'lote_cantidad' => 0,
                                ];
                                $Cant = $Detalle['lote_cantidad'];
                            elseif ($CantidadAux > 0) :
                                $Datos = [
                                    'lote_cantidad' => $Detalle['lote_cantidad'] - $CantidadAux,
                                ];
                                $Cant = $CantidadAux;
                            else :
                                break;
                            endif;
                            $Condicion = [
                                'id_detalle' => $Detalle['id_detalle'],
                            ];
                            $db->where($Condicion)->update('inv_ingresos_detalles', $Datos);
                            $CantidadAux = $CantidadAux - $Detalle['lote_cantidad'];
                            $Lote .= $Detalle['lote'] . '-' . $Cant . ',';
                        endforeach;
                        $Lote = trim($Lote, ',');
                        $DatosEgresoI[$i]['egreso_id']=$id;
                        $DatosEgresoI[$i]['lote']=$Lote;
                        $db->insert('inv_egresos_detalles',$DatosEgresoI[$i]);
                    endfor;
                    $respuesta = array(
                        'estado' => 's',
                        'estadoe' => 2
                    );
                    echo json_encode($respuesta);
                }else{
                    echo json_encode(array('estado' => 'no guardo'));
                }
            }else{
                echo json_encode(array('estado' => 'no tiene stock'));
            }
        }else{
            echo json_encode(array('estado' => 'no llego uno de los datos'));
        }
    } else {
        echo json_encode(array('estado' => 'no llego uno de los datos'));
    }
}else{
    echo json_encode(array('estado' => 'no llego los datos'));
}
?>