<?php

/**
 * FunctionPHP - Framework Functional PHP
 *
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
    // Verifica la existencia de datos
    if (isset($_POST['id_user'])) {
        // Importa la configuracion para el manejo de la base de datos
        require config . '/database.php';
        require config . '/poligono.php';

        $id_user = $_POST['id_user'];
        $dia = date('w');

        $area = $db->select('*')->from('sys_users a')->join('sys_empleados b', 'a.persona_id = b.id_empleado')->join('gps_rutas c','b.id_empleado = c.empleado_id')->where('a.id_user',$id_user)->where('c.dia',$dia)->fetch_first();

        // Obtiene los usuarios que cumplen la condicion
        $usuario = $db->from('sys_users')->join('sys_empleados','persona_id = id_empleado')->where('id_user',$_POST['id_user'])->fetch_first();
        $emp = $usuario['id_empleado'];
        $ruta = $db->from('gps_rutas')->where('empleado_id',$emp)->fetch_first();
        $fecha_actual = "".date('Y-m-d')."";
        //buscar si es vendedor o distribuidor
        if($usuario['rol_id'] == 4){
            $dis=$db->query('SELECT b.id_egreso, b.monto_total, e.nombres, e.paterno, b.observacion as estadod, c.id_cliente, c.cliente, c.nombre_factura, c.cuentas_por_cobrar, c.nit, c.telefono, c.direccion, c.descripcion, c.imagen, c.tipo, c.ubicacion AS latitud, c.ubicacion AS longitud,  b.estadoe, b.plan_de_pagos FROM gps_asigna_distribucion a
                LEFT JOIN gps_rutas d ON a.ruta_id = d.id_ruta
                LEFT JOIN sys_empleados e ON d.empleado_id = e.id_empleado
                LEFT JOIN inv_egresos b ON d.id_ruta = b.ruta_id
                LEFT JOIN inv_clientes c ON b.cliente_id = c.id_cliente
                WHERE a.distribuidor_id = '.$emp.' AND a.estado = 1 AND b.grupo="" AND b.estadoe > 1 AND b.estadoe < 3 AND (b.fecha_egreso < CURDATE() OR b.fecha_egreso <= e.fecha) GROUP BY b.cliente_id')->fetch();

            $dis1 = $db->query('SELECT b.id_egreso, b.monto_total, e.nombres, e.paterno, b.observacion AS estadod, c.id_cliente, c.cliente, c.nombre_factura, c.cuentas_por_cobrar, c.nit, c.telefono, c.direccion, c.descripcion, c.imagen, c.tipo, c.ubicacion AS latitud, c.ubicacion AS longitud,  IF(b.distribuidor_estado = "ENTREGA","3",b.estadoe) as estadoe, b.plan_de_pagos FROM gps_asigna_distribucion a
                LEFT JOIN gps_rutas d ON a.ruta_id = d.id_ruta
                LEFT JOIN sys_empleados e ON d.empleado_id = e.id_empleado
                LEFT JOIN tmp_egresos b ON d.id_ruta = b.ruta_id
                LEFT JOIN inv_clientes c ON b.cliente_id = c.id_cliente
                WHERE a.distribuidor_id = '. $emp .' AND a.estado = 1 AND b.grupo="" AND b.estadoe > 1 AND (b.distribuidor_estado = "NO ENTREGA" OR b.distribuidor_estado = "ENTREGA") AND b.estado = 3 GROUP BY b.cliente_id ORDER BY b.estadoe DESC')->fetch();

            $dis = array_merge ($dis, $dis1);

            foreach ($dis as $nro => $di) {
                if($di['plan_de_pagos']=='si'){
                    $deuda = $db->select('*')->from('inv_egresos a')
                        ->join('inv_pagos b','b.movimiento_id = a.id_egreso')
                        ->join('inv_pagos_detalles c','c.pago_id = b.id_pago')
                        ->where('c.estado',0)->where('a.plan_de_pagos','si')->where('a.cliente_id',$di['cliente_id'])->fetch_first();
                    if(empty($deuda)){
                        $dis[$nro]['estadoe'] = $di['estadoe'] + 3;
                    }
                }
                $dis[$nro]['imagen'] = ($di['imagen'] == '') ? url1 . imgs2 . '/image.jpg' : url1 . tiendas . '/' . $di['imagen'];
                $a = explode(',',$di['latitud']);
                $dis[$nro]['latitud'] = (float)$a[0];
                $dis[$nro]['longitud'] = (float)$a[1];
            }
            $aux = array();
            foreach ($dis as $nro => $di) {
                if(false){

                }else{
                    array_push($aux,$di);
                }
            }
            $respuesta = array(
                'estado' => 'd',
                'cliente' => $aux
            );
            echo json_encode($respuesta);
        }else{
//            $latitud = $_POST['latitud'];
//            $longitud = $_POST['longitud'];

            $id_almacen = $usuario['almacen_id'];
            // Obtiene los productos
            $fech = date('Y-m-d');
            $clientes = $db->query("SELECT id_cliente, cliente, nombre_factura, nit, telefono, direccion, descripcion, imagen, ubicacion, ubicacion as latitud, ubicacion as longitud, ubicacion as area, e.estadoe, e.estadoe as estadod 
            FROM inv_clientes a
            LEFT JOIN (
                SELECT b.cliente_id, b.estadoe
                FROM inv_egresos b
                WHERE b.fecha_egreso = '$fech' ORDER BY b.id_egreso ASC limit 1000 ) AS e ON a.id_cliente = e.cliente_id GROUP BY a.id_cliente")->fetch();
//            $clientes = $db->select('')->from('inv_clientes')->fetch();


            $polygon = explode('*',$area['coordenadas']);
            foreach ($polygon as $nro => $poly) {
                $aux = explode(',',$poly);
                $aux2 = (round($aux[0],6)-0.000044).','.(round($aux[1],6)+0.00003);
                $polygon[$nro] = str_replace(',', ' ', $aux2);
            }
            $polygon[0] = str_replace(',', ' ', $polygon[$nro]);
            $pointLocation = new pointLocation();

            $clientes2 = array();
            // Reformula los productos
            foreach ($clientes as $nro => $cliente) {
                $a = explode(',',$cliente['ubicacion']);
                $point = $a[0].' '.$a[1];
                $punto = $pointLocation->pointInPolygon($point, $polygon);
                if($punto == 'dentro'){
                    $cliente['latitud'] = (float)$a[0];
                    $cliente['longitud'] = (float)$a[1];
                    $cliente['nombres'] = '';
                    $cliente['paterno'] = '';
                    $cliente['imagen'] = ($cliente['imagen'] == '') ? url1 . imgs2 . '/image.jpg' : url1 . tiendas . '/' . $cliente['imagen'];

                    if(!$cliente['estadoe']){$cliente['estadoe']=0;}
                    array_push($clientes2, $cliente);
                }

            }

            // Instancia el objeto
            $respuesta = array(
                'estado' => 'v',
                'cliente' => $clientes2
            );
            // Devuelve los resultados
            echo json_encode($respuesta);
        }
    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'no llega el id usuario'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'no llega ningun dato'));
}


?>