<?php

/**
 * FunctionPHP - Framework Functional PHP
 *
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
    // Verifica la existencia de datos
    if (isset($_POST['id_user'])) {
        // Importa la configuracion para el manejo de la base de datos
        require config . '/database.php';

        // Obtiene los datos
        $id_usuario = trim($_POST['id_user']);

        // Obtiene los usuarios que cumplen la condicion
        $usuario = $db->query("select id_user, id_empleado from sys_users LEFT JOIN sys_empleados ON persona_id = id_empleado where  id_user = '$id_usuario' and active = '1' limit 1")->fetch_first();

        // Verifica la existencia del usuario
        if ($usuario) {
            
            $total = $db->select('SUM(monto_total) as total, COUNT(cliente_id) as cont')->from('inv_egresos')->where('empleado_id',$usuario['id_empleado'])->where('estadoe',2)->where('fecha_egreso',date('Y-m-d'))->where('anulado',0)->fetch_first();
            $auxf = date('Y-m-d');
            $egresos = $db->select('*')->from('inv_egresos')->where('empleado_id',$usuario['id_empleado'])->where('estadoe',2)->where('fecha_egreso',$auxf)->where('anulado',0)->fetch();
            foreach($egresos as $nro5 => $egreso){
                $detalles = $db->select('b.nombre_factura, b.nombre as unidad, a.unidad_id, a.cantidad, a.producto_id')->from('inv_egresos_detalles a')->join('inv_productos b','a.producto_id = b.id_producto')->where('promocion_id!=',1)->where('a.egreso_id',$egreso['id_egreso'])->fetch();
                foreach($detalles as $nro6 => $detalle){
                    $detalles[$nro6]['cantidad'] = (int)($detalle['cantidad']/cantidad_unidad($db, $detalle['producto_id'], $detalle['unidad_id']));
                    $detalles[$nro6]['unidad'] = nombre_unidad($db,$detalle['unidad_id']);
                }
                $egresos[$nro5]['descripcion_venta'] = $detalles;
            }
            
            // Instancia el objeto
            $respuesta = array(
                'estado' => 's',
                'nro_clientes' => $total['cont'],
                'total' => $total['total'],
                'cliente' => $egresos
            );

            // Devuelve los resultados
            echo json_encode($respuesta);
        } else {
            // Devuelve los resultados
            echo json_encode(array('estado' => 'n'));
        }
    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'n'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'n'));
}

?>