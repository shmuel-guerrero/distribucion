<?php

/**
 * FunctionPHP - Framework Functional PHP
 *
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
    // Verifica la existencia de datos
    if (isset($_POST['producto_id'])) {
        // Importa la configuracion para el manejo de la base de datos
        require config . '/database.php';

        $id_producto = $_POST['producto_id'];

        $tipo_precio1 = $db->select('precio_actual as precio, b.unidad, unidad_id')->from('inv_productos')->join('inv_unidades b','unidad_id = b.id_unidad')->where('id_producto',$id_producto)->fetch_first();
        // Obtiene los usuarios que cumplen la condicion
        $tipo_precio2 = $db->select('a.*, b.unidad')->from('inv_asignaciones a')->join('inv_unidades b','a.unidad_id = b.id_unidad')->where('producto_id',$id_producto)->fetch();

        $tipos_precios = array();

        $tipos_precios[0] = array(
            'unidad' => $tipo_precio1['unidad'],
            'id_unidad' => (int)$tipo_precio1['unidad_id'],
            'cantidad' => '1',
            'precio' => $tipo_precio1['precio']
        );
        $nro = 0;
        foreach($tipo_precio2 as $tipo_precio){
            $nro = $nro + 1;
            $tipos_precios[$nro] = array(
                'unidad' => $tipo_precio['unidad'],
                'id_unidad' => (int)$tipo_precio['unidad_id'],
                'cantidad' => $tipo_precio['cantidad_unidad'],
                'precio' => $tipo_precio['otro_precio']
            );
        }
        $respuesta = array(
            'estado' => 's',
            'tipos' => $tipos_precios
        );
        echo json_encode($respuesta);
// Verifica si el user existe

    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'no llega el id usuario'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'no llega ningun dato'));
}

?>