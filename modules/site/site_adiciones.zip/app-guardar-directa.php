<?php
/**
 * SimplePHP - Simple Framework PHP
 *
 * @package  SimplePHP
 * @author   fabio choque
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica si es una peticion post
if (is_post()) 
{
	// Verifica la existencia de los datos enviados
	
    if (isset($_POST['id_user']) && isset($_POST['cantidad']) && isset($_POST['id_unidad']) && isset($_POST['id_producto']) && isset($_POST['precio']) && isset($_POST['monto_total']))
    { 
        require config . '/database.php';

        $id_user        = trim($_POST['id_user']);
        $cantidad       = trim($_POST['cantidad']);
        $unidad         = trim($_POST['id_unidad']);
        $id_producto    = trim($_POST['id_producto']);
        $precio         = trim($_POST['precio']);
        $total          = trim($_POST['monto_total']);
        $id_cliente     = trim($_POST['codigo_cliente']);

        $usuario = $db->query("select * from sys_users LEFT JOIN sys_empleados ON persona_id = id_empleado where id_user = '$id_user' and active = '1' limit 1")->fetch_first();

        if($id_cliente != ''){
            $nombre = $usuario['nombres'];
            $nit = 0;
        }else{
            $cliente = $db->query("SELECT * FROM inv_clientes WHERE id_cliente = '$id_cliente'")->fetch_first();
            if($cliente){
                $nombre = $cliente['nombre_factura'];
                $nit = $cliente['nit'];
            }else{
                $nombre = $usuario['nombres'];
                $nit = 0;
            }
        }

        $nro_factura = $db->query("select count(id_egreso) + 1 as nro_factura from inv_egresos where tipo = 'Venta' and provisionado = 'S'")->fetch_first();
        $nro_factura = $nro_factura['nro_factura'];


        if($_POST['cantidad'] > 0){
            $nota = array(
                'fecha_egreso' => date('Y-m-d'),
                'hora_egreso' => date('H:i:s'),
                'tipo' => 'Venta',
                'provisionado' => 'S',
                'descripcion' => 'Venta de productos con productos del distribuidor',
                'nro_factura' => $nro_factura,
                'nro_autorizacion' => '',
                'codigo_control' => '',
                'fecha_limite' => '0000-00-00',
                'monto_total' => $total,
                'descuento_porcentaje' => 0,
                'descuento_bs' => 0,
                'monto_total_descuento' => 0,
                'nit_ci' => $nit,
                'nombre_cliente' => strtoupper($nombre),
                'nro_registros' => 1,
                'dosificacion_id' => 0,
                'almacen_id' => 1,
                'cobrar' => '',
                'observacion' => '',
                'empleado_id' => $usuario['id_empleado']
            );

            // Guarda la informacion
            $egreso_id = $db->insert('inv_egresos', $nota);

            $nota['distribuidor_fecha'] = date('Y-m-d');
            $nota['id_egreso'] = $egreso_id;
            $nota['distribuidor_hora'] = date('H:i:s');
            $nota['distribuidor_estado'] = 'VENTA';
            $nota['distribuidor_id'] = $usuario['id_empleado'];
            $nota['estado'] = 3;
            $id = $db->insert('tmp_egresos', $nota);

            // buscamos el producto
            $producto = $db->from('inv_productos')->where('id_producto', $id_producto)->fetch_first();
            // procesamos datos para formar el detalle
            $cantidad_u = $cantidad * cantidad_unidad($db, $id_producto, $unidad);

            /////////////////////////////////////////////////////////////////////////////////////////
            $Lote='';
            $CantidadAux=$cantidad_u;
            $Detalles=$db->query("SELECT id_detalle,cantidad,lote,lote_cantidad FROM inv_ingresos_detalles WHERE producto_id='$id_producto' AND lote_cantidad>0 ORDER BY id_detalle ASC")->fetch();
            foreach($Detalles as $Fila=>$Detalle):
                if($CantidadAux>=$Detalle['lote_cantidad']):
                    $Datos=[
                        'lote_cantidad'=>0,
                    ];
                    $Cant=$Detalle['lote_cantidad'];
                elseif($CantidadAux>0):
                    $Datos=[
                        'lote_cantidad'=>$Detalle['lote_cantidad']-$CantidadAux,
                    ];
                    $Cant=$CantidadAux;
                else:
                    break;
                endif;
                $Condicion=[
                        'id_detalle'=>$Detalle['id_detalle'],
                    ];
                $db->where($Condicion)->update('inv_ingresos_detalles',$Datos);
                $CantidadAux=$CantidadAux-$Detalle['lote_cantidad'];
                $Lote.=$Detalle['lote'].'-'.$Cant.',';
            endforeach;
            $Lote=trim($Lote,',');
            /////////////////////////////////////////////////////////////////////////////////////////
            $detalle = array(
                'cantidad' => $cantidad_u,
                'precio' => $precio,
                'unidad_id' => $unidad,
                'descuento' => 0,
                'producto_id' => $id_producto,
                'egreso_id' => $egreso_id,
                'lote'=>$Lote,
                'promocion_id' => 0
            );

            // Guarda la informacion
            $ide = $db->insert('inv_egresos_detalles', $detalle);

            $detalle['tmp_egreso_id'] = $id;
            $detalle['id_detalle'] = $ide;
            $db->insert('tmp_egresos_detalles', $detalle);

            $respuesta = array(
                'estado' => 's'
            );
            echo json_encode($respuesta);
        }else{
            // Instancia el objeto
            $respuesta = array(
                'estado' => 'la cantidad debe ser mayor a cero'
            );
            // Devuelve los resultados
            echo json_encode($respuesta);
        }
    } else {
        // Instancia el objeto
        $respuesta = array(
            'estado' => 'no llego algun dato'
        );

        // Devuelve los resultados
        echo json_encode($respuesta);
	}
} else {
    echo json_encode(array('estado' => 'no llega ningun dato'));
}
?>