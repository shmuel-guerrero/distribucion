<?php

/**
 * FunctionPHP - Framework Functional PHP
 *
 * @package  FunctionPHP
 * @author   Wilfredo Nina <wilnicho@hotmail.com>
 */

// Define las cabeceras
header('Content-Type: application/json');

// Verifica la peticion post
if (is_post()) {
    // Verifica la existencia de datos
    if (isset($_POST['id_user']) && isset($_POST['latitud']) && isset($_POST['longitud'])) {
        // Importa la configuracion para el manejo de la base de datos
        require config . '/database.php';
        require config . '/poligono.php';
        
        $id_user = $_POST['id_user'];
        $latitud = $_POST['latitud'];
        $longitud = $_POST['longitud'];
        $dia = date('w');
        $rol = $db->select('rol_id')->from('sys_users')->where('id_user',$_POST['id_user'])->fetch_first();
        $area = $db->select('*')->from('sys_users a')->join('sys_empleados b', 'a.persona_id = b.id_empleado')->join('gps_rutas c','b.id_empleado = c.empleado_id')->where('a.id_user',$id_user)->where('c.dia',$dia)->fetch_first();
//        echo json_encode($role);exit();
        if($rol['rol_id'] != 4){
            if($area){
                $point = $latitud.' '.$longitud;
                $polygon = explode('*',$area['coordenadas']);
                foreach ($polygon as $nro => $poly) {
                    $aux = explode(',',$poly);
                    $aux2 = (round($aux[0],6)-0.00005).','.(round($aux[1],6)+0.00003);
                    $polygon[$nro] = str_replace(',', ' ', $aux2);
                }
                $polygon[0] = str_replace(',', ' ', $polygon[$nro]);
                $pointLocation = new pointLocation();

                // Las últimas coordenadas tienen que ser las mismas que las primeras, para "cerrar el círculo"

                $punto = $pointLocation->pointInPolygon($point, $polygon);
                $respuesta = array(
                    'estado' => 's',
                    'lugar' => $punto
                );
            }else{
                $respuesta = array(
                    'estado' => 'sr',
                    'lugar' => 'No tiene ruta asignada'
                );
            }
        }else{
            $respuesta = array(
                'estado' => 'sd',
                'lugar' => 'Distribuidor'
            );
        }
        

echo json_encode($respuesta);
//echo json_encode($polygon);
        
    } else {
        // Devuelve los resultados
        echo json_encode(array('estado' => 'no llega el id usuario'));
    }
} else {
    // Devuelve los resultados
    echo json_encode(array('estado' => 'no llega ningun dato'));
}

?>