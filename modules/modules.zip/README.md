# 01082021 HGC
TRABAJO CONJUNTO DISTRIBUCION
trabajo de rebeca en el modulo de ventas mes de sebptiembre 2021

se agregaron nuevas tablas a la base de datos para el control de planes, modulos, atributos 

sys_planes
sys_planes_detalles
sys_planes_atributos
sys_planes_caracteristicas
sys_planes_config
sys_planes_config_detalles

se agregaron funciones al archivo extend; para la validación de de planes, usuarios, stock, validar el cambio de unidad, etc...
se optimizaron ordenaron, corrigieron, uniformaron, estandarizaron los servixios de apk
se validaron los formularíos frond-end y back-end (funciones - extend)
se restringieron las eliminaciones en varios casos


30102021 eliminar del menu asinacion de usuario

08112021 - se debera actualizar loas acrhivos del folder->start  = check, extend


